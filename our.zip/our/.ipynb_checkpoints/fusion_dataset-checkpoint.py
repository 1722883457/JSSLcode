# fusion_dataset.py
import os
import torch
import numpy as np
import dgl
from scipy import sparse as sp
from scipy.io import loadmat
from torch.utils.data import Dataset, DataLoader
from torch_geometric.data import Data as PygData

# ========== 基础：PyG <-> DGL 转换 ==========
def dgl_to_pyg(g: dgl.DGLGraph) -> PygData:
    src, dst = g.edges()
    edge_index = torch.stack([src, dst], dim=0).long()
    x = g.ndata["feature"].float() if "feature" in g.ndata else None
    y = g.ndata["label"].long() if "label" in g.ndata else None
    return PygData(x=x, edge_index=edge_index, y=y)

def pyg_to_dgl(pyg: PygData) -> dgl.DGLGraph:
    N = pyg.num_nodes
    src = pyg.edge_index[0].long().cpu()
    dst = pyg.edge_index[1].long().cpu()
    g = dgl.graph((src, dst), num_nodes=N)
    if getattr(pyg, "x", None) is not None:
        g.ndata["feature"] = pyg.x.detach().cpu().float()
    if getattr(pyg, "y", None) is not None:
        g.ndata["label"] = pyg.y.detach().cpu().long()
    return g

# ========== DGL 主入口加载 ==========
DATA_ROOTS = ["/root/autodl-tmp", "/autodl-tmp"]

def _find_first(*relative_paths):
    for root in DATA_ROOTS:
        for rp in relative_paths:
            p = os.path.join(root, rp)
            if os.path.exists(p):
                return p
    return None

def _ensure_dense(arr):
    if hasattr(arr, "toarray"):
        arr = arr.toarray()
    return np.asarray(arr)

def load_graph_dgl(name: str, add_self_loop=True, del_ratio: float = 0.0) -> dgl.DGLGraph:
    name = name.lower().strip()

    if name in ("tfinance", "tsocial"):
        path = _find_first("tfinance", "tfinance.pt")
        if path is None:
            raise FileNotFoundError("未找到 tfinance（/root/autodl-tmp/tfinance 或 tfinance.pt）")
        graphs, _ = dgl.load_graphs(path)
        g = graphs[0]

    elif name in ("reddit",):
        path = _find_first("reddit.pt", "reddit")
        if path is None:
            raise FileNotFoundError("未找到 reddit（/root/autodl-tmp/reddit.pt）")

        # 用 torch.load 读取 PyG 的 Data 对象
        data = torch.load(path)
        # data 是 PyG Data，需要转成 DGL
        src, dst = data.edge_index
        g = dgl.graph((src, dst), num_nodes=data.num_nodes)
        g.ndata["feature"] = data.x.float()
        g.ndata["label"]   = data.y.long()

    elif name in ("amazon",):
        matp = _find_first("Amazon.mat", "amazon.mat")
        if matp is None:
            raise FileNotFoundError("未找到 Amazon.mat")
        mat = loadmat(matp)
        if "homo" in mat:
            adj = mat["homo"]
        elif "adj" in mat:
            adj = mat["adj"]
        else:
            raise KeyError("Amazon.mat 缺少邻接矩阵 'homo' 或 'adj'")
        g = dgl.from_scipy(adj if sp.isspmatrix(adj) else sp.csr_matrix(adj))
        feats = _ensure_dense(mat["features"])
        labels = np.asarray(mat["label"]).reshape(-1)
        g.ndata["feature"] = torch.from_numpy(feats).float()
        g.ndata["label"]   = torch.from_numpy(labels.astype(np.int64))

    elif name in ("yelp", "yelpchi"):
        matp = _find_first("YelpChi.mat", "yelpchi.mat", "Yelp.mat", "yelp.mat")
        if matp is None:
            raise FileNotFoundError("未找到 YelpChi.mat")
        mat = loadmat(matp)
        if "homo" not in mat:
            raise KeyError("YelpChi.mat 缺少 'homo'")
        g = dgl.from_scipy(mat["homo"])
        feats = _ensure_dense(mat["features"])
        labels = np.asarray(mat["label"]).reshape(-1)
        g.ndata["feature"] = torch.from_numpy(feats).float()
        g.ndata["label"]   = torch.from_numpy(labels.astype(np.int64))

    else:
        raise ValueError(f"不支持的数据集名：{name}")

    # 可选：删边
    if del_ratio and del_ratio > 0:
        E = g.num_edges()
        keep = max(1, int(E * (1.0 - del_ratio)))
        idx = torch.randperm(E)[:keep]
        try:
            g = dgl.edge_subgraph(g, idx, relabel_nodes=False)
        except TypeError:
            g = dgl.edge_subgraph(g, idx, False)

    if add_self_loop:
        g = dgl.add_self_loop(g)

    if "feature" in g.ndata:
        g.ndata["feature"] = g.ndata["feature"].float()
    if "label" in g.ndata:
        lab = g.ndata["label"]
        g.ndata["label"] = (lab.argmax(1) if lab.dim() > 1 else lab).long()

    return g

# ========== 双视图数据容器 ==========
class FusionGraph:
    """同时持有 DGL 和 PyG 视图"""
    def __init__(self, g_dgl: dgl.DGLGraph):
        self.dgl = g_dgl
        self.pyg = dgl_to_pyg(g_dgl)
        self.y   = self.pyg.y.long() if self.pyg.y is not None else g_dgl.ndata["label"].long()

    def to(self, device):
        # 1) 先整体移动 DGLGraph
        self.dgl = self.dgl.to(device)

        # 2) 再移动 PyG tensors
        if self.pyg.x is not None:
            self.pyg.x = self.pyg.x.to(device)
        self.pyg.edge_index = self.pyg.edge_index.to(device)
        if self.pyg.y is not None:
            self.pyg.y = self.pyg.y.to(device)

        # 3) 移动标签
        self.y = self.y.to(device)

        return self

# ========== 数据集/加载器 ==========
class FusionSingleGraphDataset(Dataset):
    def __init__(self, name: str, del_ratio: float = 0.0):
        g = load_graph_dgl(name, add_self_loop=True, del_ratio=del_ratio)
        self.fusion = FusionGraph(g)

    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return self.fusion

# 新增：恒等 collate，避免 DataLoader 默认堆叠 FusionGraph
def collate_fusion(batch):
    return batch[0]

def build_fusion_dataloaders(name: str, device, del_ratio: float = 0.0, batch_size=1):
    ds = FusionSingleGraphDataset(name, del_ratio=del_ratio)
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, collate_fn=collate_fusion)
    return loader, loader, loader
