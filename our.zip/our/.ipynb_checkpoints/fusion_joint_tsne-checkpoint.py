import os
import argparse

import torch
import numpy as np
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from SECGFD.model.SECGFD import SECGFD
from GADNR.models.GADNR import GNNStructEncoder
from GADNR.dataset import load_and_prepare_dataset
from sklearn.metrics import precision_recall_curve

import scipy.io as sio


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='yelp',
                        choices=['yelp', 'amazon', 'tfinance', 'reddit'])
    parser.add_argument('--sec_hidden_dim', type=int, default=64)
    parser.add_argument('--gad_hidden_dim', type=int, default=64)
    parser.add_argument('--alpha_sec', type=float, default=0.8,
                        help='Joint = alpha * SEC + (1-alpha) * GADNR')
    parser.add_argument('--output', type=str, default='joint_tsne.png')

    # t-SNE 参数
    parser.add_argument('--perplexity', type=float, default=30.0)
    parser.add_argument('--tsne_dim', type=int, default=2)
    parser.add_argument('--random_state', type=int, default=42)
    return parser.parse_args()


def build_sec_model(dataset_name, in_dim, hid_dim, num_class, graph, device):
    model = SECGFD(in_dim, hid_dim, num_class, graph, d=2, high_order=2).to(device)
    ckpt_dir = os.path.join(os.path.dirname(__file__), 'SECGFD', 'checkpoints')
    ckpt_name = f"secgfd_{dataset_name}_best.pth"
    sec_ckpt = os.path.join(ckpt_dir, ckpt_name)
    if not os.path.exists(sec_ckpt):
        raise FileNotFoundError(f"未找到 SECGFD 权重文件: {sec_ckpt}")
    state = torch.load(sec_ckpt, map_location=device)
    model.load_state_dict(state)
    model.eval()
    print(f"[OK] Loaded SECGFD checkpoint from {sec_ckpt}")
    return model


def build_gadnr_model(dataset_name, in_dim, hid_dim, device, neighbor_num_list):
    model = GNNStructEncoder(
        in_dim0=in_dim,
        in_dim=hid_dim,
        hidden_dim=hid_dim,
        layer_num=2,
        sample_size=10,
        device=device,
        neighbor_num_list=neighbor_num_list,
        GNN_name="GCN",
        lambda_loss1=1e-2,
        lambda_loss2=0.2,
        lambda_loss3=0.7
    ).to(device)

    base_dir = os.path.dirname(__file__)
    cand_ckpts = [
        os.path.join(base_dir, 'GADNR', 'checkpoints', f'gadnr_{dataset_name}_best.pth'),
        os.path.join(base_dir, 'GADNR', 'GADNR', 'checkpoints', f'gadnr_{dataset_name}_best.pth'),
    ]
    gad_ckpt = None
    for p in cand_ckpts:
        if os.path.exists(p):
            gad_ckpt = p
            break
    if gad_ckpt is None:
        raise FileNotFoundError(f"未找到 GADNR 权重文件，尝试过: {cand_ckpts}")

    state = torch.load(gad_ckpt, map_location=device)
    model.load_state_dict(state)
    model.eval()
    print(f"[OK] Loaded GADNR checkpoint from {gad_ckpt}")
    return model


def build_neighbor_num_list(edge_index, device):
    in_nodes = edge_index[0, :]
    out_nodes = edge_index[1, :]

    neighbor_dict = {}
    for src, dst in zip(in_nodes.tolist(), out_nodes.tolist()):
        neighbor_dict.setdefault(src, []).append(dst)
    max_node = int(edge_index.max().item())
    neighbor_num_list = [len(neighbor_dict.get(i, [])) for i in range(max_node + 1)]
    return torch.tensor(neighbor_num_list, device=device)


def make_joint_embedding(emb_sec, emb_gad, alpha_sec=0.7):
    alpha = alpha_sec
    beta = 1.0 - alpha
    joint = alpha * emb_sec + beta * emb_gad
    joint = joint / (joint.norm(dim=1, keepdim=True) + 1e-8)
    return joint


def main():
    args = parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("Device:", device)

    # ===== 1. 加载图和特征 =====
    data, _, _, _, _, _ = load_and_prepare_dataset(
        dataset_str=args.dataset,
        device=device,
        args=argparse.Namespace(
            data_root="/autodl-tmp",
            normalize_feat=False,
            calculate_contextual=False,
            calculate_structural=False,
            use_combine_outlier=False,
        )
    )

    x = data.x
    edge_index = data.edge_index
    num_nodes = x.size(0)
    in_dim = x.size(1)
    num_class = 2
    print(f"[INFO] num_nodes={num_nodes}, in_dim={in_dim}")

    # ===== 2. 读取真实标签 =====
    mat_path = "/root/autodl-tmp/YelpChi.mat"
    mat = sio.loadmat(mat_path)
    y_true = mat["label"].reshape(-1).astype(int)
    assert y_true.shape[0] == num_nodes, \
        f"label 数量 {y_true.shape[0]} != 节点数 {num_nodes}"
    print("[INFO] 真实标签统计 (0=normal,1=anomaly):", np.bincount(y_true))

    # ===== 3. 构建 SEC / GADNR 模型并取 embedding =====
    neighbor_num_list = build_neighbor_num_list(edge_index, device)

    from dgl import graph as dgl_graph
    src = edge_index[0].cpu()
    dst = edge_index[1].cpu()
    g_dgl = dgl_graph((src, dst), num_nodes=num_nodes).to(device)

    secgfd = build_sec_model(args.dataset, in_dim, args.sec_hidden_dim, num_class, g_dgl, device)
    gadnr = build_gadnr_model(args.dataset, in_dim, args.gad_hidden_dim, device, neighbor_num_list)

    secgfd.eval()
    gadnr.eval()

    with torch.no_grad():
        logits_sec, emb_sec = secgfd(x)                         # [N, H_sec]
        emb_gad = gadnr.encode_only(edge_index, x, device=device)  # [N, H_gad]

    # === 用 SEC 的异常概率作为 anomaly score ===
    probs_sec = logits_sec.softmax(dim=1)[:, 1].cpu().numpy()   # 每个节点的“异常概率”

    # 对齐维度
    if emb_sec.size(1) != emb_gad.size(1):
        proj = torch.nn.Linear(emb_gad.size(1), emb_sec.size(1)).to(device)
        with torch.no_grad():
            emb_gad = proj(emb_gad)
    H = emb_sec.size(1)

    joint_emb = make_joint_embedding(emb_sec, emb_gad, alpha_sec=args.alpha_sec)
    joint_emb = joint_emb.cpu().numpy()   # [N, H]

    # ===== 4. 选取“最正常”的 4000 个 Normal + “最异常”的 400 个 Anomaly =====
    y = y_true
    idx_anom = np.where(y == 1)[0]   # 真实异常索引
    idx_norm = np.where(y == 0)[0]   # 真实正常索引

    # 4.1 正常：在真实 normal 中按异常概率从小到大排序，取前 4000 个
    num_norm_keep = min(3000, len(idx_norm))
    norm_scores = probs_sec[idx_norm]               # 正常节点上的异常概率
    order_norm = np.argsort(norm_scores)            # 从小到大 => 越小越“正常”
    sel_norm = idx_norm[order_norm[:num_norm_keep]]

    # 4.2 异常：在真实 abnormal 中按异常概率从大到小排序，取前 400 个
    num_anom_keep = min(3000, len(idx_anom))
    anom_scores = probs_sec[idx_anom]
    order_anom = np.argsort(anom_scores)[::-1]      # 从大到小 => 越大越“异常”
    sel_anom = idx_anom[order_anom[:num_anom_keep]]

    # 4.3 合并
    idx_keep = np.concatenate([sel_norm, sel_anom], axis=0)
    labels_keep = y_true[idx_keep]
    joint_keep = joint_emb[idx_keep]

    print(f"[VIS] 选取 MOST-Normal={num_norm_keep} 个 + MOST-Anomaly={num_anom_keep} 个，共 {len(idx_keep)} 个点可视化。")
    print("labels_keep bincount:", np.bincount(labels_keep))

    # ===== 5. 标准化 + PCA =====
    scaler = StandardScaler()
    joint_norm = scaler.fit_transform(joint_keep)

    pca = PCA(n_components=min(50, H))
    joint_pca = pca.fit_transform(joint_norm)

    # ===== 6. t-SNE =====
    tsne = TSNE(
        n_components=args.tsne_dim,
        perplexity=args.perplexity,
        learning_rate=200,
        n_iter=2000,
        init='pca',
        random_state=args.random_state,
        metric='euclidean',
    )
    print("[TSNE] fitting...")
    joint_tsne = tsne.fit_transform(joint_pca)
    print("[TSNE] done. joint_tsne shape:", joint_tsne.shape)

    # ===== 7. 画图：蓝 = Normal(0)，红 = Anomaly(1) =====
    plt.figure(figsize=(6, 6))
    normal_mask = (labels_keep == 0)
    anomaly_mask = (labels_keep == 1)

    # 公共样式：不含 zorder
    scatter_kwargs = dict(
        s=15,
        linewidths=0.3,
        alpha=0.9,
    )

    # 先画 normal（底层）
    plt.scatter(
        joint_tsne[normal_mask, 0], joint_tsne[normal_mask, 1],
        c='royalblue',
        edgecolors='#27408B',   # 边框和填充同色，看起来更“实心”
        label='Normal',
        zorder=1,
        **scatter_kwargs
    )

    # 再画 anomaly（上层）
    plt.scatter(
        joint_tsne[anomaly_mask, 0], joint_tsne[anomaly_mask, 1],
        c='red',
        edgecolors='#8B0000',
        label='Anomaly',
        zorder=2,
        **scatter_kwargs
    )

    plt.xticks([])
    plt.yticks([])
    plt.legend(loc='best', fontsize=10)
    plt.tight_layout()
    plt.savefig(args.output, dpi=300)
    print(f"[OK] Joint t-SNE saved to {args.output}")


if __name__ == "__main__":
    main()
