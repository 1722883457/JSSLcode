# fusion_models.py (optimized version with Lc and caching)
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
from sklearn.model_selection import train_test_split

# ===== 你的两侧模型（SECGFD 在前，GADNR 在后）=====
from SECGFD.model.SECGFD import SECGFD as SECGFDNet
from GADNR.models.GADNR import GNNStructEncoder as GADNRNet


# ====== add: Softmax Focal Loss for multi-class (2-class) ======
class FocalLossSoftmax(nn.Module):
    def __init__(self, gamma: float = 2.0, alpha=None, reduction: str = "mean"):
        super().__init__()
        self.gamma = gamma
        self.reduction = reduction
        self.register_buffer("alpha_vec", None)
        if alpha is not None:
            if isinstance(alpha, (list, tuple)):
                alpha = torch.tensor(alpha, dtype=torch.float32)
            elif isinstance(alpha, (float, int)):
                alpha = torch.tensor([1.0 - float(alpha), float(alpha)], dtype=torch.float32)
            self.register_buffer("alpha_vec", alpha)

    def forward(self, logits, targets):
        probs = torch.softmax(logits, dim=1)
        pt = probs.gather(1, targets.view(-1, 1)).clamp_(1e-8, 1.0)
        logpt = pt.log()
        if self.alpha_vec is not None:
            alpha = self.alpha_vec.to(logits.device)
            at = alpha.gather(0, targets)
            loss = - at * ((1 - pt) ** self.gamma).squeeze(1) * logpt.squeeze(1)
        else:
            loss = - ((1 - pt) ** self.gamma).squeeze(1) * logpt.squeeze(1)
        return loss.mean() if self.reduction == "mean" else loss.sum() if self.reduction == "sum" else loss





# ========== GADNR 包装（优化：缓存邻居与模型） ==========
class GADNRWrapper(nn.Module):
    def __init__(
        self,
        encoder: str = "GCN",
        hidden_dim: int = 16,
        sample_size: int = 10,
        lambda_loss1: float = 1e-2,
        lambda_loss2: float = 0.2,
        lambda_loss3: float = 0.7,
        h_loss_weight: float = 1.0,
        feature_loss_weight: float = 2.0,
        degree_loss_weight: float = 1.0,
        neigh_loss: str = "KL",
    ):
        super().__init__()
        self.encoder = encoder
        self.hidden_dim = hidden_dim
        self.sample_size = sample_size
        self.lambda_loss1 = lambda_loss1
        self.lambda_loss2 = lambda_loss2
        self.lambda_loss3 = lambda_loss3
        self.h_w = h_loss_weight
        self.f_w = feature_loss_weight
        self.d_w = degree_loss_weight
        self.neigh_loss = neigh_loss

        self.model: Optional[nn.Module] = None
        self._cached_graph_key = None
        self._cached_neighbor_dict = None
        self._cached_neighbor_num_list = None

    @staticmethod
    def _build_neighbor_dict(edge_index: torch.Tensor, num_nodes: int):
        neighbor_dict = {i: [] for i in range(int(num_nodes))}
        src = edge_index[0].tolist()
        dst = edge_index[1].tolist()
        for u, v in zip(src, dst):
            neighbor_dict[u].append(v)
        neighbor_num_list = torch.tensor(
            [len(neighbor_dict[i]) for i in range(int(num_nodes))],
            dtype=torch.long
        )
        return neighbor_dict, neighbor_num_list

    def _maybe_build_model(self, pyg, device):
        key = (pyg.num_nodes, pyg.edge_index.size(1), pyg.x.size(1))
        if self.model is not None and self._cached_graph_key == key:
            return

        neighbor_dict, neighbor_num_list = self._build_neighbor_dict(pyg.edge_index, pyg.num_nodes)
        neighbor_num_list = neighbor_num_list.to(device)

        self.model = GADNRNet(
            in_dim0=pyg.x.size(1),
            in_dim=self.hidden_dim,
            hidden_dim=self.hidden_dim,
            layer_num=2,
            sample_size=self.sample_size,
            device=device,
            neighbor_num_list=neighbor_num_list,
            GNN_name=self.encoder,
            lambda_loss1=self.lambda_loss1,
            lambda_loss2=self.lambda_loss2,
            lambda_loss3=self.lambda_loss3,
        ).to(device)

        self._cached_graph_key = key
        self._cached_neighbor_dict = neighbor_dict
        self._cached_neighbor_num_list = neighbor_num_list

    def forward_and_loss(self, fusion_batch):
        pyg = fusion_batch.pyg
        device = pyg.x.device

        # ✅ 构建一次后缓存
        if self.model is None:
            self._maybe_build_model(pyg, device)

        neighbor_dict = self._cached_neighbor_dict
        neighbor_num_list = self._cached_neighbor_num_list

        loss, loss_per_node, h_loss, degree_loss, feature_loss = self.model(
            pyg.edge_index, pyg.x, neighbor_num_list, neighbor_dict, device
        )

        h = h_loss.detach().cpu()
        d = degree_loss.detach().cpu()
        f = feature_loss.detach().cpu()

        h_norm = h / (h.max() - h.min() + 1e-8)
        d_norm = d / (d.max() - d.min() + 1e-8)
        f_norm = f / (f.max() - f.min() + 1e-8)

        comp_loss = (self.h_w * h_norm + self.d_w * d_norm + self.f_w * f_norm).squeeze(1)
        pred = comp_loss.to(device).float()
        return loss, pred
# ========== SEC-GFD 包装（优化：只初始化一次） ==========
class SECWrapper(nn.Module):
    def __init__(
        self,
        hid_dim: int = 64,
        order: int = 2,
        train_ratio: float = 0.4,
        seed: int = 2,
        temp: float = 1.0,
        use_focal: bool = False,
        focal_gamma: float = 2.0,
        focal_alpha: float | None = None,
        sec_device: str | None = None,
        **kwargs,
    ):
        super().__init__()
        self.hid_dim = hid_dim
        self.order = order
        self.train_ratio = train_ratio
        self.seed = seed
        self.temp = float(temp)
        self.use_focal = bool(use_focal)
        self.focal_gamma = float(focal_gamma)
        self.focal_alpha_user = focal_alpha
        self._sec_device_str = sec_device
        self.model: Optional[nn.Module] = None
        self._masks_built = False
        self._train_mask = None
        self._val_mask = None
        self._test_mask = None
        self._criterion = None

    def _maybe_build(self, g: "dgl.DGLGraph"):
        device = torch.device(self._sec_device_str) if self._sec_device_str else g.device
        if self.model is not None and self._masks_built:
            return

        g_dev = g.to(device)
        in_dim = g_dev.ndata["feature"].shape[1]
        num_class = 2
        self.model = SECGFDNet(in_dim, self.hid_dim, num_class, g_dev, d=self.order, high_order=2).to(device)

        labels_cpu = g_dev.ndata["label"].long().cpu()
        index = list(range(len(labels_cpu)))
        idx_train, idx_rest, y_train, y_rest = train_test_split(
            index, labels_cpu[index], stratify=labels_cpu[index],
            train_size=self.train_ratio, random_state=self.seed, shuffle=True
        )
        idx_valid, idx_test, _, _ = train_test_split(
            idx_rest, y_rest, stratify=y_rest,
            test_size=0.67, random_state=self.seed, shuffle=True
        )

        N = len(labels_cpu)
        self._train_mask = torch.zeros([N], dtype=torch.bool, device=device)
        self._val_mask   = torch.zeros([N], dtype=torch.bool, device=device)
        self._test_mask  = torch.zeros([N], dtype=torch.bool, device=device)
        self._train_mask[idx_train] = True
        self._val_mask[idx_valid]   = True
        self._test_mask[idx_test]   = True

        labels_train = g_dev.ndata["label"].long().to(device)[self._train_mask]
        pos = (labels_train == 1).sum().item()
        neg = (labels_train == 0).sum().item()
        auto_alpha_pos = neg / max(pos + neg, 1)

        if self.use_focal:
            alpha_for_focal = self.focal_alpha_user if self.focal_alpha_user is not None else float(auto_alpha_pos)
            self._criterion = FocalLossSoftmax(
                gamma=self.focal_gamma,
                alpha=alpha_for_focal,
                reduction="mean"
            ).to(device)
        else:
            ce_weight = torch.tensor([1.0, neg / max(pos, 1)], device=device)
            self._criterion = lambda logits, targets: F.cross_entropy(
                logits, targets, weight=ce_weight
            )

        self._masks_built = True

    def forward_and_loss(self, fusion_batch):
        g = fusion_batch.dgl
        if self.model is None:
            self._maybe_build(g)

        device = next(self.model.parameters()).device
        g_dev = g.to(device)
        features = g_dev.ndata["feature"]
        labels   = g_dev.ndata["label"].long().to(device)

        logits, emb = self.model(features)
        logits_scaled = logits / self.temp if (self.temp and self.temp > 0) else logits

        loss = self._criterion(logits_scaled[self._train_mask], labels[self._train_mask])
        probs = torch.softmax(logits_scaled, dim=1)
        return loss, probs[:, 1]

# ========== 融合器（含一致性损失 Lc + 自动设备对齐） ==========
class FusionModel(nn.Module):
    def __init__(self, gadnr_cfg: dict, sec_cfg: dict, alpha=0.2, beta=0.8):
        super().__init__()
        self.alpha = float(alpha)  # 控制 SEC
        self.beta = float(beta)    # 控制 GADNR
        
        
        self.s = SECWrapper(**sec_cfg)
        self.g = GADNRWrapper(**gadnr_cfg)

        self.register_buffer("g_mu", torch.tensor(1.0))
        self.register_buffer("s_mu", torch.tensor(1.0))
        self._ema = 0.9

    def _normalize_scores(self, pred_g, pred_s):
        dev = pred_g.device

        pg = torch.nan_to_num(pred_g, nan=0.0, posinf=0.0, neginf=0.0)
        pg_min, pg_max = pg.min(), pg.max()
        pg_norm = (pg - pg_min) / (pg_max - pg_min + 1e-8)

        ps = torch.nan_to_num(pred_s, nan=0.5, posinf=1.0, neginf=0.0).clamp(0, 1).to(dev)
        return pg_norm, ps

    def forward_train(self, fusion_batch):
        loss_g, pred_g = self.g.forward_and_loss(fusion_batch)
        loss_s, pred_s = self.s.forward_and_loss(fusion_batch)

        pg_norm, ps = self._normalize_scores(pred_g, pred_s)
        

        eps = 1e-6
        self.g_mu = self._ema * self.g_mu + (1 - self._ema) * loss_g.detach().abs()
        self.s_mu = self._ema * self.s_mu + (1 - self._ema) * loss_s.detach().abs()

        loss_g_norm = loss_g / (self.g_mu + eps)
        loss_s_norm = loss_s / (self.s_mu + eps)

        loss_total = self.alpha * loss_g_norm + self.beta * loss_s_norm 

        return loss_total, {
            "loss_g": loss_g,
            "loss_s": loss_s,
            "loss_g_norm": loss_g_norm.detach(),
            "loss_s_norm": loss_s_norm.detach(),
            "pred_g": pred_g,
            "pred_s": pred_s,
        }

    @torch.no_grad()
    def forward_eval_prob(self, fusion_batch):
        _, pred_g = self.g.forward_and_loss(fusion_batch)
        _, pred_s = self.s.forward_and_loss(fusion_batch)
        pg_norm, ps = self._normalize_scores(pred_g, pred_s)
        p = self.alpha * pg_norm + self.beta * ps
        return torch.nan_to_num(p, nan=0.5, posinf=1.0, neginf=0.0).clamp(0, 1)
