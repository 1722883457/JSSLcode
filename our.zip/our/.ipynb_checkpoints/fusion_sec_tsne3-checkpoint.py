import os
import argparse

import torch
import numpy as np
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_recall_curve

from SECGFD.model.SECGFD import SECGFD
from GADNR.dataset import load_and_prepare_dataset
import scipy.io as sio


# ----------------- 参数 -----------------
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='amazon',
                        choices=['yelp', 'amazon', 'tfinance', 'reddit'])
    parser.add_argument('--sec_hidden_dim', type=int, default=32)
    parser.add_argument('--output', type=str, default='sec_tsne.png')

    # t-SNE 参数
    parser.add_argument('--perplexity', type=float, default=30.0)
    parser.add_argument('--tsne_dim', type=int, default=2)
    parser.add_argument('--random_state', type=int, default=42)
    return parser.parse_args()


# ----------------- 工具函数 -----------------
def build_sec_model(dataset_name, in_dim, hid_dim, num_class, graph, device):
    """按你训练时的方式构造 SECGFD 模型并加载 checkpoint"""
    model = SECGFD(in_dim, hid_dim, num_class, graph, d=2, high_order=2).to(device)

    ckpt_dir = os.path.join(os.path.dirname(__file__), 'SECGFD', 'checkpoints')
    ckpt_name = f"secgfd_{dataset_name}_best.pth"
    sec_ckpt = os.path.join(ckpt_dir, ckpt_name)
    if not os.path.exists(sec_ckpt):
        raise FileNotFoundError(f"未找到 SECGFD 权重文件: {sec_ckpt}")
    state = torch.load(sec_ckpt, map_location=device)
    model.load_state_dict(state)
    model.eval()
    print(f"[OK] Loaded SECGFD checkpoint from {sec_ckpt}")
    return model


def find_best_f1_threshold(y_true, scores):
    """
    用 PR 曲线在所有阈值上搜索 F1 最大的点，返回 best_thr, best_f1
    y_true:  一维 0/1 标签（numpy）
    scores:  一维 分数（越大越异常，numpy）
    """
    p, r, thr = precision_recall_curve(y_true, scores)
    f1 = (2 * p * r) / (p + r + 1e-12)
    if np.all(np.isnan(f1)):
        return 0.5, 0.0
    idx = int(np.nanargmax(f1))
    best_thr = 0.0 if idx == 0 else float(thr[idx - 1])
    return best_thr, float(f1[idx])


# ----------------- 主流程 -----------------
def main():
    args = parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("Device:", device)

    # 1. 用 GADNR 的 dataset 代码加载图和特征
    data, _, _, _, _, _ = load_and_prepare_dataset(
        dataset_str=args.dataset,
        device=device,
        args=argparse.Namespace(
            data_root="/autodl-tmp",
            normalize_feat=False,
            calculate_contextual=False,
            calculate_structural=False,
            use_combine_outlier=False,
        )
    )

    x = data.x                      # [N, F]
    edge_index = data.edge_index    # [2, E]
    num_nodes = x.size(0)
    in_dim = x.size(1)
    num_class = 2
    print(f"[INFO] num_nodes={num_nodes}, in_dim={in_dim}")

    # 2. 读取真实标签（这里你之前 Amazon 用的是 /root/autodl-tmp/Amazon.mat）
    #    如果以后要画 yelp/tfinance/reddit，可以在这里做个小映射。
    if args.dataset == 'amazon':
        mat_path = "/root/autodl-tmp/Amazon.mat"
    elif args.dataset == 'yelp':
        mat_path = "/root/autodl-tmp/YelpChi.mat"
    elif args.dataset == 'tfinance':
        mat_path = "/root/autodl-tmp/TFinance.mat"
    elif args.dataset == 'reddit':
        mat_path = "/root/autodl-tmp/Reddit.mat"
    else:
        raise ValueError(f"未知数据集 {args.dataset}，请自己改 mat_path")

    mat = sio.loadmat(mat_path)
    y_true = mat["label"].reshape(-1).astype(int)   # [N]
    assert y_true.shape[0] == num_nodes, \
        f"label 数量 {y_true.shape[0]} != 节点数 {num_nodes}"
    print("[INFO] 真实标签统计 (0=normal,1=anomaly):", np.bincount(y_true))

    # 3. 构建 DGL 图 + SECGFD 模型，取 SEC embedding
    from dgl import graph as dgl_graph
    src = edge_index[0].cpu()
    dst = edge_index[1].cpu()
    g_dgl = dgl_graph((src, dst), num_nodes=num_nodes).to(device)

    secgfd = build_sec_model(args.dataset, in_dim, args.sec_hidden_dim, num_class, g_dgl, device)
    secgfd.eval()

    with torch.no_grad():
        logits_sec, emb_sec = secgfd(x)   # logits: [N,2], emb_sec: [N,H]

    # 4. 打印一下 SEC 的 best F1（可选）
    probs_sec = logits_sec.softmax(dim=1)[:, 1].cpu().numpy()   # 异常概率
    best_thr, best_f1 = find_best_f1_threshold(y_true, probs_sec)
    print(f"[SEC] best F1={best_f1:.4f} at thr={best_thr:.4f}")

    sec_emb = emb_sec.cpu().numpy()       # [N, H]
    H = sec_emb.shape[1]

    # 5. 全部节点 + 真实标签画图
    idx_keep = np.arange(num_nodes)
    labels_keep = y_true.copy()
    sec_keep = sec_emb[idx_keep]
    print(f"[SEC-TSNE] Using ALL {sec_keep.shape[0]} nodes for visualization.")

    # 6. 标准化 + PCA
    scaler = StandardScaler()
    sec_norm = scaler.fit_transform(sec_keep)

    pca = PCA(n_components=min(50, H))
    sec_pca = pca.fit_transform(sec_norm)

    # 7. t-SNE
    tsne = TSNE(
        n_components=args.tsne_dim,
        perplexity=args.perplexity,
        learning_rate=200,
        n_iter=2000,
        init='pca',
        random_state=args.random_state,
        metric='euclidean',
    )
    print("[SEC-TSNE] Fitting t-SNE...")
    sec_tsne = tsne.fit_transform(sec_pca)
    print("[SEC-TSNE] Done, sec_tsne shape =", sec_tsne.shape)

    # ===== 8. 画图：蓝 = Normal(0)，红 = Anomaly(1) =====
    plt.figure(figsize=(6, 6))
    normal_mask = (labels_keep == 0)
    anomaly_mask = (labels_keep == 1)

    # 先画 Normal：点更小、更透明，放底层
    plt.scatter(
        sec_tsne[normal_mask, 0], sec_tsne[normal_mask, 1],
        s=2,                      # 很小
        c='royalblue',
        alpha=0.15,               # 很透明
        label='Normal',
        zorder=1
    )

    # 再画 Anomaly：点更大、有描边、放上层
    plt.scatter(
        sec_tsne[anomaly_mask, 0], sec_tsne[anomaly_mask, 1],
        s=30,                      # 大很多
        c='red',
        edgecolors='k',            # 黑色描边
        linewidths=0.3,
        alpha=0.95,                # 基本不透明
        marker='o',                # 实心圆
        label='Anomaly',
        zorder=3
    )


    plt.xticks([])
    plt.yticks([])
    plt.legend(loc='best', fontsize=10)
    plt.tight_layout()
    plt.savefig(args.output, dpi=300)
    print(f"[OK] SEC-only t-SNE saved to {args.output}")


if __name__ == "__main__":
    main()
