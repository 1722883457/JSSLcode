#fusion_train.py
import os, sys
ROOT = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(ROOT, "GADNR"))
sys.path.append(os.path.join(ROOT, "SECGFD"))  # SECGFD 优先

import torch
from sklearn.metrics import roc_auc_score
from fusion_models import FusionModel
from fusion_dataset import build_fusion_dataloaders  # 双视图数据入口
import numpy as np

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ========= F1-macro & G-Mean 计算工具 =========
def _f1_macro_from_labels_np(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int = 2) -> float:
    eps = 1e-12
    y_true = y_true.astype(np.int64)
    y_pred = y_pred.astype(np.int64)
    f1s = []
    if num_classes is None:
        num_classes = int(max(y_true.max(), y_pred.max())) + 1
        num_classes = max(num_classes, 2)
    for c in range(num_classes):
        tp = np.sum((y_true == c) & (y_pred == c))
        fp = np.sum((y_true != c) & (y_pred == c))
        fn = np.sum((y_true == c) & (y_pred != c))
        precision = tp / (tp + fp + eps)
        recall    = tp / (tp + fn + eps)
        f1 = 2 * precision * recall / (precision + recall + eps)
        f1s.append(f1)
    return float(np.mean(f1s)) if len(f1s) > 0 else 0.0

def f1_macro_from_probs_np(p: np.ndarray, y: np.ndarray, thr: float = 0.5) -> float:
    y = y.astype(np.int64)
    y_pred = (p >= float(thr)).astype(np.int64)
    return _f1_macro_from_labels_np(y, y_pred, num_classes=2)

def f1_macro_best_np(p: np.ndarray, y: np.ndarray, thr_grid: np.ndarray = None):
    if thr_grid is None:
        thr_grid = np.linspace(0.01, 0.99, 99)  # 可按需调密度
    best_f1, best_thr = -1.0, 0.5
    for t in thr_grid:
        f1 = f1_macro_from_probs_np(p, y, thr=t)
        if f1 > best_f1:
            best_f1, best_thr = f1, float(t)
    return best_f1, best_thr

# ------- 仅保留：基于阈值搜索的 G-Mean（最大值） -------
def gmean_from_probs_np(p: np.ndarray, y: np.ndarray, thr: float) -> float:
    """
    G-Mean = sqrt(TPR * TNR)；TPR=TP/(TP+FN), TNR=TN/(TN+FP)
    """
    eps = 1e-12
    y = y.astype(np.int64)
    y_pred = (p >= float(thr)).astype(np.int64)

    tp = np.sum((y == 1) & (y_pred == 1))
    fn = np.sum((y == 1) & (y_pred == 0))
    tn = np.sum((y == 0) & (y_pred == 0))
    fp = np.sum((y == 0) & (y_pred == 1))

    tpr = tp / (tp + fn + eps)
    tnr = tn / (tn + fp + eps)
    return float(np.sqrt(max(tpr, 0.0) * max(tnr, 0.0) + eps))

def gmean_best_np(p: np.ndarray, y: np.ndarray, thr_grid: np.ndarray = None):
    """
    返回：最大 G-Mean 及其对应阈值
    """
    if thr_grid is None:
        thr_grid = np.linspace(0.01, 0.99, 99)
    best_g, best_thr = -1.0, 0.5
    for t in thr_grid:
        g = gmean_from_probs_np(p, y, thr=t)
        if g > best_g:
            best_g, best_thr = g, float(t)
    return best_g, best_thr
# ==========================================

scaler = torch.cuda.amp.GradScaler()

def train_one_epoch(model, loader, optim):
    model.train()
    total = 0.0
    for fusion_batch in loader:
        fusion_batch = fusion_batch.to(DEVICE)
        optim.zero_grad()

        # ✅ 用 forward_train（返回 loss_total 和日志）
        loss_total, logs = model.forward_train(fusion_batch)

        # 训练期再加一层 NaN 守卫，避免梯度是 NaN
        if torch.isnan(loss_total) or torch.isinf(loss_total):
            print("[warn] loss_total is NaN/Inf in train_one_epoch — skip this step")
            continue

        loss_total.backward()
        optim.step()
        total += float(loss_total.item())

    return total / max(1, len(loader))

@torch.no_grad()
def evaluate_metrics(model, loader):
    """
    评估指标：
      - ROC AUC（基于融合概率）
      - F1-macro@best（在 [0.01,0.99] 搜阈值）
      - G-Mean（最大值）及对应阈值
    """
    model.eval()
    probs, labels = [], []
    for fusion_batch in loader:
        fusion_batch = fusion_batch.to(DEVICE)
        p = model.forward_eval_prob(fusion_batch)  # [N] 正类概率
        y = fusion_batch.y.float()                 # [N]
        probs.append(p.detach().flatten().cpu())
        labels.append(y.detach().flatten().cpu())
    p = torch.cat(probs).numpy()
    y = torch.cat(labels).numpy()

    # NaN/Inf 防护
    if not np.all(np.isfinite(p)):
        print("[warn] NaN detected in predictions, replacing with safe values")
        p = np.nan_to_num(p, nan=0.5, posinf=1.0, neginf=0.0)

    # AUC（若 y 全 0 或全 1，AUC 会报错，这里做兜底）
    try:
        auc = roc_auc_score(y, p)
    except Exception as e:
        print(f"[warn] roc_auc_score error: {e} -> set auc=0.5")
        auc = 0.5

    # 仅保留 “最佳阈值” 版本
    f1_best, best_thr_f1 = f1_macro_best_np(p, y)
    gmean_best, best_thr_gmean = gmean_best_np(p, y)

    return {
        "auc": auc,
        "f1_best": f1_best,
        "best_thr_f1": best_thr_f1,
        "gmean": gmean_best,             # 直接作为 G-Mean（最大值）
        "best_thr_gmean": best_thr_gmean
    }

def main():
    # ====== 数据集：'tfinance' / 'amazon' / 'yelpchi' / 'reddit' ======
    DATASET = "amazon"

    # ====== DataLoader（整图任务 batch_size=1 即可） ======
    train_loader, val_loader, test_loader = build_fusion_dataloaders(
        DATASET, DEVICE, del_ratio=0.0, batch_size=1
    )

    # ====== 两侧超参（按你单独实验的最佳配置改） ======
    gadnr_cfg = dict(
        encoder="GCN",
        hidden_dim=32,  # 确保使用 'hidden_dim'
        sample_size=10,
        lambda_loss1=1e-2,
        lambda_loss2=0.5,
        lambda_loss3=0.8,
        h_loss_weight=1.0,
        feature_loss_weight=2.0,
        degree_loss_weight=1.0,
        neigh_loss="KL",
    )

    sec_cfg = dict(
        hidden_dim=64,  # 确保使用 'hidden_dim' 而不是 'hid_dim'
        order=5,
        train_ratio=0.4,
        seed=2,
        #sec_device="cpu",
    )

    # ====== 融合器（alpha=0.1、beta=0.9） ======
    model = FusionModel(
        gadnr_cfg,
        sec_cfg,
        alpha=0.2,
        beta=0.8,
    ).to(DEVICE)

    # >>> 关键修复：先用一个 batch 触发内部子模型参数的创建，再建优化器 <<<
    sample = next(iter(train_loader))
    sample = sample.to(DEVICE)
    with torch.no_grad():
        _ = model.forward_train(sample)

    # 现在参数已创建，不会再出现“optimizer got an empty parameter list”
    optim = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)

    # ====== 训练 ======
    best_auc, best_auc_ep = 0.0, -1
    best_f1,  best_f1_ep, best_f1_thr = 0.0, -1, 0.5
    best_gmean, best_gmean_ep, best_gmean_thr = 0.0, -1, 0.5  # 仅追踪最大 G-Mean

    EPOCHS = 1000
    for ep in range(EPOCHS):
        tr_loss = train_one_epoch(model, train_loader, optim)

        val_stats = evaluate_metrics(model, val_loader)
        val_auc         = val_stats["auc"]
        val_f1_best     = val_stats["f1_best"]
        val_best_thr_f1 = val_stats["best_thr_f1"]
        val_gmean       = val_stats["gmean"]           # 直接就是最大 G-Mean
        val_best_thr_gm = val_stats["best_thr_gmean"]

        # —— 按 AUC 选最优权重（与原逻辑一致）——
        if val_auc > best_auc:
            best_auc, best_auc_ep = val_auc, ep
            torch.save(model.state_dict(), f"fusion_best_{DATASET}.pt")

        # —— 记录 F1-macro 最佳 —— 
        if val_f1_best > best_f1:
            best_f1, best_f1_ep, best_f1_thr = val_f1_best, ep, val_best_thr_f1

        # —— 记录 G-Mean（最大值） —— 
        if val_gmean > best_gmean:
            best_gmean, best_gmean_ep, best_gmean_thr = val_gmean, ep, val_best_thr_gm

        print(
            f"[{ep:03d}] loss={tr_loss:.4f}  "
            f"valAUC={val_auc:.4f}  "
            f"valF1={val_f1_best:.4f} (thr={val_best_thr_f1:.3f})  "
            f"valGMean={val_gmean:.4f} (thr={val_best_thr_gm:.3f})  "
            f"bestAUC@{best_auc_ep}:{best_auc:.4f}  "
            f"bestF1@{best_f1_ep}:{best_f1:.4f} (thr={best_f1_thr:.3f})  "
            f"bestGMean@{best_gmean_ep}:{best_gmean:.4f} (thr={best_gmean_thr:.3f})"
        )

    # ====== 测试：用 AUC 最优的权重 ======
    model.load_state_dict(torch.load(f"fusion_best_{DATASET}.pt", map_location=DEVICE))
    test_stats = evaluate_metrics(model, test_loader)
    test_auc         = test_stats["auc"]
    test_f1_best     = test_stats["f1_best"]
    test_best_thr_f1 = test_stats["best_thr_f1"]
    test_gmean       = test_stats["gmean"]           # 最大 G-Mean
    test_best_thr_gm = test_stats["best_thr_gmean"]

    print(
        f"[FUSION] bestAUC@{best_auc_ep}:{best_auc:.4f}  "
        f"Test AUC={test_auc:.4f} | Test F1={test_f1_best:.4f} (thr={test_best_thr_f1:.3f}) | "
        f"Test GMean={test_gmean:.4f} (thr={test_best_thr_gm:.3f})"
    )

if __name__ == "__main__":
    main()
