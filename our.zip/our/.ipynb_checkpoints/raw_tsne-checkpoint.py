import os
import argparse

import torch
import numpy as np
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from GADNR.dataset import load_and_prepare_dataset
import scipy.io as sio


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='yelp',
                        choices=['yelp', 'amazon', 'tfinance', 'reddit'])
    parser.add_argument('--output', type=str, default='raw_tsne.png')

    # t-SNE 参数
    parser.add_argument('--perplexity', type=float, default=30.0)
    parser.add_argument('--tsne_dim', type=int, default=2)
    parser.add_argument('--random_state', type=int, default=42)
    return parser.parse_args()


def get_mat_path(dataset):
    """根据数据集名字返回 .mat 路径，你可以按自己路径改一下。"""
    name_map = {
        'amazon': 'Amazon.mat',
        'yelp': 'YelpChi.mat',
        'tfinance': 'Tfinance.mat',
        'reddit': 'Reddit.mat',
    }
    mat_name = name_map[dataset]
    return os.path.join("/root/autodl-tmp", mat_name)


def main():
    args = parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("Device:", device)

    # ===== 1. 加载图和“原始特征” =====
    data, _, _, _, _, _ = load_and_prepare_dataset(
        dataset_str=args.dataset,
        device=device,
        args=argparse.Namespace(
            data_root="/autodl-tmp",
            normalize_feat=False,          # 这里仍然是你原来用的设置
            calculate_contextual=False,
            calculate_structural=False,
            use_combine_outlier=False,
        )
    )

    x = data.x.cpu().numpy()     # [N, F] 直接拿 raw features
    num_nodes, in_dim = x.shape
    print(f"[INFO] num_nodes={num_nodes}, in_dim={in_dim}")

    # ===== 2. 加载真实标签 =====
    mat_path = get_mat_path(args.dataset)
    mat = sio.loadmat(mat_path)
    y_true = mat["label"].reshape(-1).astype(int)
    assert y_true.shape[0] == num_nodes, \
        f"label 数量 {y_true.shape[0]} != 节点数 {num_nodes}"
    print("[INFO] 真实标签统计 (0=normal,1=anomaly):", np.bincount(y_true))

    # ===== 3. 可选：为了可视化，随机下采样一些 normal =====
    idx_anom = np.where(y_true == 1)[0]
    idx_norm = np.where(y_true == 0)[0]

    rng = np.random.RandomState(args.random_state)
    # 比如最多保留 5000 个 normal，全体 anomaly 都画
    max_norm = 5000
    num_norm_keep = min(max_norm, len(idx_norm))
    sel_norm = rng.choice(idx_norm, size=num_norm_keep, replace=False)

    sel_anom = idx_anom                       # 全部异常
    idx_keep = np.concatenate([sel_norm, sel_anom])
    labels_keep = y_true[idx_keep]
    x_keep = x[idx_keep]

    print(f"[VIS] Raw features：Normal={len(sel_norm)} + Anomaly={len(sel_anom)}，共 {len(idx_keep)} 个点。")
    print("labels_keep bincount:", np.bincount(labels_keep))

    # ===== 4. 标准化 + PCA =====
    scaler = StandardScaler()
    x_norm = scaler.fit_transform(x_keep)

    pca = PCA(n_components=min(50, in_dim))
    x_pca = pca.fit_transform(x_norm)

    # ===== 5. t-SNE =====
    tsne = TSNE(
        n_components=args.tsne_dim,
        perplexity=args.perplexity,
        learning_rate=200,
        n_iter=2000,
        init='pca',
        random_state=args.random_state,
        metric='euclidean',
    )
    print("[TSNE] fitting on raw features...")
    x_tsne = tsne.fit_transform(x_pca)
    print("[TSNE] done. x_tsne shape:", x_tsne.shape)

    # ===== 6. 画图：Raw Features t-SNE =====
    plt.figure(figsize=(6, 6))
    normal_mask = (labels_keep == 0)
    anomaly_mask = (labels_keep == 1)

    # 为了跟你 Joint 图统一风格
    scatter_kwargs = dict(
        s=8,
        linewidths=0.3,
        alpha=0.9,
    )

    plt.scatter(
        x_tsne[normal_mask, 0], x_tsne[normal_mask, 1],
        c='royalblue',
        edgecolors='#27408B',
        label='Normal',
        zorder=1,
        **scatter_kwargs
    )
    plt.scatter(
        x_tsne[anomaly_mask, 0], x_tsne[anomaly_mask, 1],
        c='red',
        edgecolors='#8B0000',
        label='Anomaly',
        zorder=2,
        **scatter_kwargs
    )

    plt.xticks([])
    plt.yticks([])
    plt.legend(loc='best', fontsize=10)
    plt.tight_layout()
    plt.savefig(args.output, dpi=300)
    print(f"[OK] Raw t-SNE saved to {args.output}")


if __name__ == "__main__":
    main()
