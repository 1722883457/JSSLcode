# dataset.py
# ------------------------------------------------------------
# 本地优先的四数据集加载器（YelpChi.mat / Amazon.mat / tfinance/ reddit(.pt)）
# 集成：
#   - 特征归一化（min-max，--normalize_feat）
#   - 异常注入：contextual/structural/joint（与原脚本逻辑一致）
#   - 可选合并标签 (--use_combine_outlier)
#   - 自环
#   - to(device)
# 返回：data, y(布尔CPU), yc, ys, yj, ysj（均CPU张量，若未生成则为空张量）
# ------------------------------------------------------------

import os
import numpy as np
import torch
from torch_geometric.data import Data
# from pygod.utils import load_data              # ← 不再联网下载，删掉

try:
    from pygod.generator import gen_contextual_outlier, gen_structural_outlier
except Exception:
    print("[dataset] pygod.generator 中没有 gen_contextual_outlier / gen_structural_outlier，"
          "使用本地简化版本（不注入异常，仅返回全 0 标签）。")

    import torch

    def gen_contextual_outlier(data, n=0, k=0):
        """
        本地兜底版：不改动图结构，只返回全 0 的 yc。
        这样训练主流程能正常跑，contextual AUC 只是没有意义。
        """
        y_ctx = torch.zeros(data.x.shape[0], dtype=torch.long)
        return data, y_ctx

    def gen_structural_outlier(data, n=0, m=0, p=0.2):
        """
        本地兜底版：不改动图结构，只返回全 0 的 ys。
        """
        y_str = torch.zeros(data.x.shape[0], dtype=torch.long)
        return data, y_str

from pygod.utils.utility import check_parameter

try:
    import scipy.io as scio
    from scipy.sparse import issparse as _sp_issparse
except Exception:
    scio = None
    _sp_issparse = None


try:
    from dgl.data.utils import load_graphs
    import dgl
except Exception:
    load_graphs = None
    dgl = None

# -----------------------------
# 工具
# -----------------------------
def _minmax_(x: torch.Tensor) -> torch.Tensor:
    mn, mx = x.min(), x.max()
    return (x - mn) / (mx - mn + 1e-8)

def _to_edge_index_from_adj(adj):
    """
    将 .mat 中的 adj 转换为 edge_index (2, E)
    支持：
      - 稀疏矩阵（scipy.sparse）
      - 稠密 ndarray（非零即边）
      - 已经是 (2, E) indices 形式
    """
    if torch.is_tensor(adj):
        if adj.dim() == 2 and adj.size(0) == 2:  # already edge_index
            return adj.long()
        arr = adj.detach().cpu().numpy()
    else:
        arr = adj

    # 如果是 (2,E) 的 numpy/int64
    if isinstance(arr, np.ndarray) and arr.ndim == 2 and arr.shape[0] == 2:
        return torch.from_numpy(arr).long()

    # 稀疏矩阵
    if _sp_issparse is not None:
        try:
            if _sp_issparse(arr):
                coo = arr.tocoo()
                rows, cols = coo.row.astype(np.int64), coo.col.astype(np.int64)
                return torch.from_numpy(np.vstack([rows, cols])).long()
        except Exception:
            pass

    # 稠密邻接
    arr = np.asarray(arr)
    nz = np.nonzero(arr)
    rows, cols = nz[0].astype(np.int64), nz[1].astype(np.int64)
    return torch.from_numpy(np.vstack([rows, cols])).long()

def _try_load_local_pt(pt_path: str):
    try:
        return torch.load(pt_path) if (pt_path and os.path.exists(pt_path)) else None
    except Exception as e:
        print(f"[dataset] 读取本地PT失败 {pt_path}: {e}")
        return None

def _find_existing_path(root: str, candidates):
    """在 root 下依次查找第一个存在的候选路径（大小写与后缀都兼容）"""
    for cand in candidates:
        p = os.path.join(root, cand)
        if os.path.exists(p):
            return p
    return None

def add_self_loops_inplace(data: Data) -> Data:
    n = data.x.size(0)
    self_edges = torch.stack([torch.arange(n), torch.arange(n)], dim=0)  # [2,N]
    data.edge_index = torch.cat([data.edge_index.cpu(), self_edges], dim=1)
    return data


# -----------------------------
# 联合结构异常（与原脚本一致，兼容 (m,n) 旧式与关键字）
# -----------------------------
def gen_joint_structural_outliers(data, *args, random_state=None, **kwargs):
    n = kwargs.get("n", None)
    m = kwargs.get("m", None)
    if n is None or m is None:
        if len(args) >= 2 and all(isinstance(v, int) for v in args[:2]):
            m, n = int(args[0]), int(args[1])  # legacy positional (m, n)
        else:
            raise ValueError("Please provide n and m (keywords) or legacy positional (m, n).")

    if not isinstance(data, Data):
        raise TypeError("data should be torch_geometric.data.Data")

    if isinstance(m, int):
        check_parameter(m, low=0, high=data.num_nodes, param_name='m')
    else:
        raise ValueError(f"m should be int, got {type(m)}")

    if isinstance(n, int):
        check_parameter(n, low=0, high=data.num_nodes, param_name='n')
    else:
        raise ValueError(f"n should be int, got {type(n)}")

    check_parameter(m * n, low=0, high=data.num_nodes, param_name='m*n')
    if random_state is not None:
        np.random.seed(random_state)

    outlier_idx = np.random.choice(data.num_nodes, size=n, replace=False)

    new_edges = []
    for i in outlier_idx.tolist():
        other_idx = np.random.choice(data.num_nodes, size=m, replace=False)
        for j in other_idx:
            new_edges.append(torch.tensor([[i, j]], dtype=torch.long))

    if len(new_edges) > 0:
        new_edges = torch.cat(new_edges)  # [E,2]
        data.edge_index = torch.cat([data.edge_index, new_edges.T], dim=1)

    y_outlier = torch.zeros(data.x.shape[0], dtype=torch.long)
    y_outlier[outlier_idx] = 1
    return data, y_outlier


# -----------------------------
# 主入口：加载 + 归一化 + 异常注入 + 自环 + to(device)
# -----------------------------
def load_and_prepare_dataset(
    dataset_str: str,
    device: torch.device,
    args
):
    """
    仅按固定绝对路径加载，不做其他形式的加载或联网：
      - reddit        -> /autodl-tmp/reddit.pt
      - tfinance      -> /autodl-tmp/tfinance.pt
      - amazon        -> /autodl-tmp/Amazon.mat
      - yelp/yelpchi  -> /autodl-tmp/YelpChi.mat
    返回： data, y(布尔CPU), yc, ys, yj, ysj
    """
    name = dataset_str.lower().strip()

    # 1) 严格按固定路径读取
    if name == "reddit":
        pt_path = "/autodl-tmp/reddit.pt"
        if not os.path.exists(pt_path):
            raise FileNotFoundError(f"[dataset] 缺少 {pt_path}")
        data = torch.load(pt_path)
    
    elif dataset_str.lower() == 'tfinance':
        # 使用 DGL 加载图数据
        graphs, label_dict = dgl.load_graphs('/autodl-tmp/tfinance')
        graph = graphs[0]  # 取第一个图
        print("Loaded tfinance dataset successfully!")

        # 打印 data.ndata 中的字段


        # 标签处理：如果标签是多分类的（one-hot），通过 argmax 转为整数标签
        graph.ndata['label'] = graph.ndata['label'].argmax(1)

        # 删除边（如果指定比例不为 0）
        if del_ratio != 0:
            graph = random_delete(graph, del_ratio)

        # 添加自环
        graph = dgl.add_self_loop(graph)

        # 将 DGLGraph 转换为 torch_geometric.data.Data 格式
        edge_index = graph.edges()[0]  # DGL 图的边
        x = graph.ndata['feature']  # DGL 图的节点特征
        y = graph.ndata['label']  # DGL 图的标签

        # 创建 PyTorch Geometric Data 对象
        data = Data(x=x, edge_index=edge_index, y=y)

        # 继续处理数据
          # 打印转换后的数据字段

        # 1) 读取 DGL 图
        graphs, label_dict = load_graphs(path)
        if not graphs:
            raise RuntimeError(f"[dataset] {path} 内未读取到有效 DGL 图")
        g = graphs[0]

        # 2) 随机抽边（默认使用 args.tfinance_edge_keep，未提供则用 1.0=不抽样）
        KEEP_RATIO = float(getattr(args, "tfinance_edge_keep", 1.0))
        E = g.num_edges()
        if KEEP_RATIO < 1.0:
            keep = max(1, int(E * KEEP_RATIO))
            idx = torch.randperm(E, dtype=torch.int64)[:keep]
            # 兼容不同 DGL 版本：用 relabel_nodes=False 来“保留原节点编号”
            try:
                g = dgl.edge_subgraph(g, idx, relabel_nodes=False)
            except TypeError:
                g = dgl.edge_subgraph(g, idx, False)
            print(f"[tfinance] downsampled edges: {E} -> {g.num_edges()} (keep_ratio={KEEP_RATIO})")

        # 3) 低维特征，避免一次性加载超大原始特征
        in_deg = g.in_degrees().view(-1, 1).float()
        out_deg = g.out_degrees().view(-1, 1).float()
        x = torch.cat([in_deg, out_deg], dim=1)

        # 4) 标签
        if "label" in g.ndata:
            y_nd = g.ndata["label"]
        else:
            raise KeyError("tfinance 缺少标签：ndata['label']")
        y = y_nd.argmax(1).long() if y_nd.dim() > 1 else y_nd.long()

        # 5) 边 -> PyG
        src, dst = g.edges()
        edge_index = torch.stack([src, dst], dim=0).long()   # PyG 规范：long indices
        data = Data(x=x.float(), edge_index=edge_index, y=y) # 与模型权重一致：float32

    elif name == "amazon":
        # 优先使用 --data_root，其次两个常见目录
        roots = []
        user_root = getattr(args, "data_root", None)
        if user_root:
            roots.append(user_root)
        roots += ["/root/autodl-tmp", "/autodl-tmp"]

        cand_files = ["Amazon.mat", "amazon.mat"]
        mat_path = None
        for rt in roots:
            for cf in cand_files:
                p = os.path.join(rt, cf)
                if os.path.exists(p):
                    mat_path = p
                    break
            if mat_path:
                break

        if not mat_path:
            raise FileNotFoundError("[dataset] 缺少 Amazon.mat，请放到 /root/autodl-tmp 或 /autodl-tmp，"
                                    "或用 --data_root 指定目录")

        print(f"[dataset] Amazon.mat 使用路径：{mat_path}")

        if scio is None:
            raise ImportError("需要 scipy 读取 .mat：请先 pip install -U scipy")
        mat = scio.loadmat(mat_path)

        # 邻接：优先 'adj'，否则 'homo'
        if "adj" in mat:
            adj_like = mat["adj"]
        elif "homo" in mat:
            adj_like = mat["homo"]
        else:
            raise KeyError(f"{mat_path} 缺少邻接：'adj' 或 'homo'")

        # 特征
        if "features" not in mat:
            raise KeyError(f"{mat_path} 缺少 'features'")
        feats = mat["features"]
        if hasattr(feats, "toarray"):
            feats = feats.toarray()
        x = torch.from_numpy(np.asarray(feats)).float()

        # 标签
        if "label" not in mat:
            raise KeyError(f"{mat_path} 缺少 'label'")
        labels = np.asarray(mat["label"]).reshape(-1)
        y_long = torch.from_numpy(labels.astype(np.int64))

        edge_index = _to_edge_index_from_adj(adj_like)
        data = Data(x=x, edge_index=edge_index, y=y_long)

    elif name in ("yelp", "yelpchi"):
        roots = []
        user_root = getattr(args, "data_root", None)
        if user_root:
            roots.append(user_root)
        roots += ["/root/autodl-tmp", "/autodl-tmp"]

        cand_files = ["YelpChi.mat", "yelpchi.mat", "Yelp.mat", "yelp.mat"]
        mat_path = None
        for rt in roots:
            for cf in cand_files:
                p = os.path.join(rt, cf)
                if os.path.exists(p):
                    mat_path = p
                    break
            if mat_path:
                break

        if not mat_path:
            raise FileNotFoundError("[dataset] 缺少 YelpChi.mat，请放到 /root/autodl-tmp 或 /autodl-tmp，"
                                    "或用 --data_root 指定目录")

        print(f"[dataset] YelpChi.mat 使用路径：{mat_path}")

        if scio is None:
            raise ImportError("需要 scipy 读取 .mat：请先 pip install -U scipy")
        mat = scio.loadmat(mat_path)

        if "adj" in mat:
            adj_like = mat["adj"]
        elif "homo" in mat:
            adj_like = mat["homo"]
        else:
            raise KeyError(f"{mat_path} 缺少邻接：'adj' 或 'homo'")

        if "features" not in mat:
            raise KeyError(f"{mat_path} 缺少 'features'")
        feats = mat["features"]
        if hasattr(feats, "toarray"):
            feats = feats.toarray()
        x = torch.from_numpy(np.asarray(feats)).float()

        if "label" not in mat:
            raise KeyError(f"{mat_path} 缺少 'label'")
        labels = np.asarray(mat["label"]).reshape(-1)
        y_long = torch.from_numpy(labels.astype(np.int64))

        edge_index = _to_edge_index_from_adj(adj_like)
        data = Data(x=x, edge_index=edge_index, y=y_long)

    else:
        raise ValueError(f"[dataset] 不支持的数据集名：{dataset_str}")

    # ===== 特征归一化（按需）=====
    if getattr(args, "normalize_feat", False):
        data.x = _minmax_(data.x)

    # ===== 异常注入 =====
    yc = torch.tensor([])
    ys = torch.tensor([])
    yj = torch.tensor([])

    # -------- 上下文异常（contextual outlier）--------
    # 对 args 做健壮处理：没有这些字段就用默认值，不再报 AttributeError
    if getattr(args, "calculate_contextual", False):
        n_ctx = getattr(args, "contextual_n", 0)
        k_ctx = getattr(args, "contextual_k", 0)
        if dataset_str == "inj_cora":
            yc = data.y >> 0 & 1
        else:
            data, yc = gen_contextual_outlier(data=data, n=n_ctx, k=k_ctx)
        yc = yc.cpu().detach()
    else:
        # 不计算 contextual 的情况，返回全 0（维度和节点数对齐）
        yc = torch.zeros(data.x.size(0), dtype=torch.long)

    # -------- 结构异常（structural / joint）--------
    if getattr(args, "calculate_structural", False):
        n_str = getattr(args, "structural_n", 0)
        m_str = getattr(args, "structural_m", 0)

        if dataset_str == "inj_cora":
            ys = data.y >> 1 & 1
        else:
            data, ys = gen_structural_outlier(data=data, n=n_str, m=m_str, p=0.2)
        ys = ys.cpu().detach()

        # joint structural
        data, yj = gen_joint_structural_outliers(data=data, n=n_str, m=m_str)
        yj = yj.cpu().detach()
    else:
        ys = torch.zeros(data.x.size(0), dtype=torch.long)
        yj = torch.zeros(data.x.size(0), dtype=torch.long)

    # 可选：合并标签
    if getattr(args, "use_combine_outlier", False):
        if ys.numel() and yc.numel():
            data.y = torch.logical_or(ys, yc).int()

    # y / ysj（若未生成 ys 或 yj，则为空）
    if ys.numel() and yj.numel():
        ysj = torch.logical_or(ys, yj).int()
    else:
        ysj = torch.tensor([])

    y = data.y.bool().cpu().detach()

    # ===== 自环 + to(device) =====
    data = add_self_loops_inplace(data)
    data = data.to(device)

    return data, y, yc, ys, yj, ysj
