# losses.py
# ------------------------------------------------------------
# 集合了项目里用到的损失函数：
# 1) KL_neighbor_loss     —— 邻域分布（高斯）KL 散度（与原版一致）
# 2) W2_neighbor_loss     —— 邻域分布 2-Wasserstein 距离（与原版一致）
# 3) cal_nceloss          —— 全局 NCE 风格对比损失（SEC-GFD utils.py 中的实现）
# ------------------------------------------------------------

import math
import numpy as np
import torch
import torch.nn.functional as F
from typing import Optional
try:
    # W2 需要用到的矩阵平方根
    from scipy.linalg import sqrtm
except Exception:
    sqrtm = None  # 若环境未安装 scipy，也能导入本文件；用到 W2 时会报出更清晰的错误。


# ---------------------------------------------------------------------
# 1) KL 邻域损失（与原脚本一致）
# ---------------------------------------------------------------------
def KL_neighbor_loss(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    mask_len: int,
    device: Optional[torch.device] = None,
) -> torch.Tensor:
    """
    计算两组样本（视作多元高斯）的 KL(target || prediction)。
    与原始实现保持一致：先估计均值/协方差，再按闭式解计算 KL。
    参数
    ----
    predictions: [1, S, D] 或 [S, D] 的 tensor（模型生成的邻域样本）
    targets    : [1, S, D] 或 [S, D] 的 tensor（真实邻域样本）
    mask_len   : 未使用（保留与原函数签名一致）
    device     : 可选，把最终标量移到 device（与原版保持行为）
    """
    # 与原版相同：在 CPU 上做统计，避免 GPU 上的 tiny 数值差异
    x1 = predictions.squeeze().cpu().detach()
    x2 = targets.squeeze().cpu().detach()

    mean_x1 = x1.mean(0)  # [D]
    mean_x2 = x2.mean(0)  # [D]
    nn_ = x1.shape[0]
    h_dim = x1.shape[1]

    cov_x1 = (x1 - mean_x1).transpose(1, 0).matmul(x1 - mean_x1) / max((nn_ - 1), 1)
    cov_x2 = (x2 - mean_x2).transpose(1, 0).matmul(x2 - mean_x2) / max((nn_ - 1), 1)

    eye = torch.eye(h_dim)
    cov_x1 = cov_x1 + eye
    cov_x2 = cov_x2 + eye

    KL_loss = 0.5 * (
        math.log(torch.det(cov_x1) / torch.det(cov_x2))
        - h_dim
        + torch.trace(torch.inverse(cov_x2).matmul(cov_x1))
        + (mean_x2 - mean_x1).reshape(1, -1).matmul(torch.inverse(cov_x2)).matmul(mean_x2 - mean_x1)
    )
    if device is not None:
        KL_loss = KL_loss.to(device)
    return KL_loss


# ---------------------------------------------------------------------
# 2) 2-Wasserstein 邻域损失（与原脚本一致）
# ---------------------------------------------------------------------
def W2_neighbor_loss(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    mask_len: int,
) -> torch.Tensor:
    """
    计算两组样本（视作多元高斯）的 2-Wasserstein 距离的平方（默认与原版一致，直接拼公式）。
    参数
    ----
    predictions: [1, S, D] 或 [S, D]
    targets    : [1, S, D] 或 [S, D]
    mask_len   : 未使用（保留签名一致）
    说明
    ----
    依赖 scipy.linalg.sqrtm；如果你的环境没有 scipy，请安装：pip install scipy
    """
    if sqrtm is None:
        raise ImportError("W2_neighbor_loss 需要 scipy.linalg.sqrtm，请先安装 scipy：pip install scipy")

    x1 = predictions.squeeze().cpu().detach()
    x2 = targets.squeeze().cpu().detach()
    mean_x1 = x1.mean(0)
    mean_x2 = x2.mean(0)

    nn_ = x1.shape[0]
    cov_x1 = (x1 - mean_x1).transpose(1, 0).matmul(x1 - mean_x1) / max((nn_ - 1), 1)
    cov_x2 = (x2 - mean_x2).transpose(1, 0).matmul(x2 - mean_x2) / max((nn_ - 1), 1)

    # 注意：sqrtm 接受 numpy 数组
    cov1 = cov_x1.cpu().numpy()
    cov2 = cov_x2.cpu().numpy()
    root1 = sqrtm(cov1)
    mid = root1 @ cov2 @ root1
    root_mid = sqrtm(mid)

    # W2^2 = ||m1-m2||^2 + Tr(C1 + C2 - 2*(C1^{1/2} C2 C1^{1/2})^{1/2})
    mean_term = torch.square(mean_x1 - mean_x2).sum()
    cov_term = torch.trace(cov_x1 + cov_x2 - 2 * torch.tensor(root_mid.real))
    W2 = mean_term + cov_term
    return W2


# ---------------------------------------------------------------------
# 3) 全局 NCE 风格损失（来自你截图的 SEC-GFD/utils.py）
# ---------------------------------------------------------------------
def cal_nceloss(
    emb: torch.Tensor,
    features: torch.Tensor,
    labels: torch.Tensor,
    idx_train: torch.Tensor,
) -> torch.Tensor:
    """
    全局级对比损失：让训练子集中“正常”节点的 (features, emb) 余弦相似度均值
    显著大于“异常”节点的均值：  loss = - log( mean_normal / mean_abnormal )

    参数
    ----
    emb      : [N, D]   模型学到的节点表示
    features : [N, D]   原始/处理后的节点特征（与 emb 同维度）
    labels   : [N]      0=正常, 1=异常
    idx_train: [K]      训练子集索引（只在这部分上计算统计量）

    返回
    ----
    标量损失（float tensor）
    """
    # 选择训练子集
    sub_labels = labels[idx_train]

    # 两类索引（至少各有一个，否则会 NaN/报错；这里不处理，保持与原实现一致）
    train_normal_index  = torch.where(sub_labels == 0)[0]
    train_anomaly_index = torch.where(sub_labels == 1)[0]

    # 在全量上计算每个节点的 features↔emb 相似度，然后再选择训练子集里的索引
    sim_score = F.cosine_similarity(features, emb)  # [N]
    sim_sub   = sim_score[idx_train]

    abn = torch.mean(sim_sub[train_anomaly_index])
    nor = torch.mean(sim_sub[train_normal_index])

    # 与原语义一致；加入微小 eps 防止 0 除（不会改变非极端情况下的数值趋势）
    eps = 1e-12
    nce_loss = -torch.log((nor + eps) / (abn + eps))
    return nce_loss


__all__ = [
    "KL_neighbor_loss",
    "W2_neighbor_loss",
    "cal_nceloss",
]