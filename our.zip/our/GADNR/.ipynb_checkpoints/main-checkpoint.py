import sys
sys.path.append("..")

import argparse
import torch

from trainer import train_real_datasets

def parse_args():
    parser = argparse.ArgumentParser(description='parameters')
    parser.add_argument('-f')
    parser.add_argument('--dataset', type=str, default="amazon")
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epoch_num', type=int, default=200)
    parser.add_argument('--lambda_loss1', type=float, default=1e-2)  # neighbor reconstruction loss weight
    parser.add_argument('--lambda_loss2', type=float, default=0.2)   # feature loss weight
    parser.add_argument('--lambda_loss3', type=float, default=0.7)   # degree loss weight
    parser.add_argument('--sample_size', type=int, default=10)
    parser.add_argument('--dimension', type=int, default=16)
    parser.add_argument('--encoder', type=str, default="GCN")
    parser.add_argument('--loss_step', type=int, default=50)
    parser.add_argument('--real_loss', type=bool, default=False)  # use real loss or adaptive loss
    parser.add_argument('--neigh_loss', type=str, default="KL")   # "KL" or "W2"
    parser.add_argument('--h_loss_weight', type=float, default=1.0)   # adaptive loss weight for h_loss (comb loss显示用)
    parser.add_argument('--feature_loss_weight', type=float, default=2.0)
    parser.add_argument('--degree_loss_weight', type=float, default=1.0)
    parser.add_argument('--calculate_contextual', type=bool, default=True)
    parser.add_argument('--contextual_n', type=int, default=183)
    parser.add_argument('--contextual_k', type=int, default=30)
    parser.add_argument('--calculate_structural', type=bool, default=True)
    parser.add_argument('--structural_n', type=int, default=183)
    parser.add_argument('--structural_m', type=int, default=30)
    parser.add_argument('--use_combine_outlier', type=bool, default=False)
    parser.add_argument('--plot_loss', type=bool, default=False)
    parser.add_argument('--normalize_feat', type=bool, default=False)
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("GAD-NR: Graph Anomaly Detection via Neighborhood Reconstruction")
    print(
        "Dataset:", args.dataset,
        "lr:", args.lr,
        "lambda_loss1 (neighbor):", args.lambda_loss1,
        "lambda_loss2 (feature):", args.lambda_loss2,
        "lambda_loss3 (degree):", args.lambda_loss3,
        "sample_size:", args.sample_size,
        "dimension:", args.dimension,
        "encoder:", args.encoder,
        "loss_step:", args.loss_step,
        "real_loss:", args.real_loss,
        "h_loss_weight:", args.h_loss_weight,
        "feature_loss_weight", args.feature_loss_weight,
        "degree_loss_weight:", args.degree_loss_weight,
        "calculate_contextual", args.calculate_contextual,
        "calculate_structural", args.calculate_structural
    )

    train_real_datasets(
        dataset_str=args.dataset, epoch_num=args.epoch_num, lr=args.lr, encoder=args.encoder,
        lambda_loss1=args.lambda_loss1, lambda_loss2=args.lambda_loss2, lambda_loss3=args.lambda_loss3,
        sample_size=args.sample_size, loss_step=args.loss_step, hidden_dim=args.dimension,
        real_loss=args.real_loss, calculate_contextual=args.calculate_contextual,
        calculate_structural=args.calculate_structural, device=device, args=args
    )