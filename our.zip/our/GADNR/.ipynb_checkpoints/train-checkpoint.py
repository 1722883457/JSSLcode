# train.py的代码
import sys
sys.path.append("..")

# —— 其它 import 可以保留，这里不动 —— #
import dgl
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm
import statistics
import random
import math
import matplotlib.pyplot as plt

from torch.autograd import Variable
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv, GINConv, SAGEConv, GATConv, PNAConv, GraphSAGE
from torch_geometric.transforms import normalize_features
from torch_geometric.datasets import Reddit

#from pygod.utils import load_data

#from pygod.generator import gen_contextual_outlier, gen_structural_outlier
from sklearn.metrics import roc_auc_score
from scipy.optimize import linear_sum_assignment
import scipy
import scipy.optimize
from scipy.linalg import sqrtm

import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import sklearn as sk
import networkx as nx

import argparse
import os, sys
import torch

from losses import KL_neighbor_loss, W2_neighbor_loss
# ★ 不要再导入 load_dataset_ifelse / add_self_loop_inplace ★
# from dataset import load_dataset_ifelse, add_self_loop_inplace
from dataset import load_and_prepare_dataset           # ★ 只用这一条 ★
from models.GADNR import GNNStructEncoder
from utils import PairNorm, FNN, MLP, MLP_generator, gen_joint_structural_outliers, _normalize


def eval_roc_auc(y_true, y_score):
    """
    兼容原来 pygod.metric.eval_roc_auc 的接口，
    返回 [0,1] 之间的 AUC（外面会 *100）
    """
    return roc_auc_score(y_true, y_score)

def train(data, y, yc, ys, yj, ysj, lr, epoch, device, encoder,
          lambda_loss1, lambda_loss2, lambda_loss3, hidden_dim,
          sample_size=10, loss_step=20, real_loss=False,
          calculate_contextual=False, calculate_structural=False, args=None):

    in_nodes = data.edge_index[0, :]
    out_nodes = data.edge_index[1, :]

    # ==== 新增：AUC 相关的最佳值记录（一定要在 for 循环外先初始化） ====
    best_auc = 0.0
    best_auc_contextual = 0.0
    best_auc_dense_structural = 0.0
    best_auc_joint_structural = 0.0
    best_auc_structure_type = 0.0
    # ==============================================================
    
    neighbor_dict = {}
    for in_node, out_node in zip(in_nodes, out_nodes):
        if in_node.item() not in neighbor_dict:
            neighbor_dict[in_node.item()] = []
        neighbor_dict[in_node.item()].append(out_node.item())

    neighbor_num_list = []
    for i in neighbor_dict:
        neighbor_num_list.append(len(neighbor_dict[i]))
    neighbor_num_list = torch.tensor(neighbor_num_list).to(device)

    in_dim = data.x.shape[1]
    GNNModel = GNNStructEncoder(
        in_dim0=in_dim, in_dim=hidden_dim, hidden_dim=hidden_dim, layer_num=2,
        sample_size=sample_size, device=device, neighbor_num_list=neighbor_num_list,
        GNN_name=encoder, lambda_loss1=lambda_loss1, lambda_loss2=lambda_loss2, lambda_loss3=lambda_loss3
    ).to(device)

    degree_params = list(map(id, GNNModel.degree_decoder.parameters()))
    base_params = filter(lambda p: id(p) not in degree_params, GNNModel.parameters())
    opt = torch.optim.Adam(
        [{'params': base_params}, {'params': GNNModel.degree_decoder.parameters(), 'lr': 1e-2}],
        lr=lr, weight_decay=0.0003
    )

    min_loss = float('inf')
    arg_min_loss_per_node = None
    
    ckpt_dir = os.path.join(os.path.dirname(__file__), "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)
    ckpt_path = os.path.join(ckpt_dir, f"gadnr_{args.dataset}_best.pth")


    
    loss_values = []

    for i in tqdm(range(1, epoch + 1, 1)):
        if i % loss_step == 0:
            GNNModel.lambda_loss2 = GNNModel.lambda_loss2 + 0.5
            GNNModel.lambda_loss3 = GNNModel.lambda_loss3 * 2

        loss, loss_per_node, h_loss, degree_loss, feature_loss = GNNModel(
            data.edge_index, data.x, neighbor_num_list, neighbor_dict, device
        )

        loss_per_node = loss_per_node.cpu().detach()
        h_loss_cpu = h_loss.cpu().detach()
        degree_loss_cpu = degree_loss.cpu().detach()
        feature_loss_cpu = feature_loss.cpu().detach()

        h_loss_norm = h_loss_cpu / (torch.max(h_loss_cpu) - torch.min(h_loss_cpu) + 1e-8)
        degree_loss_norm = degree_loss_cpu / (torch.max(degree_loss_cpu) - torch.min(degree_loss_cpu) + 1e-8)
        feature_loss_norm = feature_loss_cpu / (torch.max(feature_loss_cpu) - torch.min(feature_loss_cpu) + 1e-8)

        comb_loss = (
            args.h_loss_weight * h_loss_norm
            + args.degree_loss_weight * degree_loss_norm
            + args.feature_loss_weight * feature_loss_norm
        )
        comp_loss = loss_per_node if real_loss else comb_loss

        auc_score = eval_roc_auc(y.numpy(), comp_loss.numpy()) * 100
        print("Dataset Name: ", args.dataset, ", AUC Score(benchmark/combined): ", auc_score)

                # === 新增：保存最优 GADNR 模型 ===
        if auc_score > best_auc:
            best_auc = auc_score
            ckpt_dir = "./GADNR/checkpoints"
            os.makedirs(ckpt_dir, exist_ok=True)
            best_ckpt_path = os.path.join(ckpt_dir, f"gadnr_{args.dataset}_best.pth")
            torch.save(GNNModel.state_dict(), best_ckpt_path)
            print(f"[GADNR] Saved best model to {best_ckpt_path}")
        
        if calculate_contextual:
            contextual_auc_score = eval_roc_auc(yc.numpy(), comp_loss.numpy()) * 100
            print("Dataset Name: ", args.dataset, ", AUC Score (contextual): ", contextual_auc_score)
            best_auc_contextual = max(best_auc_contextual, contextual_auc_score)

        if calculate_structural:
            dense_structural_auc_score = eval_roc_auc(ys.numpy(), comp_loss.numpy()) * 100
            print("Dataset Name: ", args.dataset, ", AUC Score (structural): ", dense_structural_auc_score)
            joint_structural_auc_score = eval_roc_auc(yj.numpy(), comp_loss.numpy()) * 100
            print("Dataset Name: ", args.dataset, ", AUC Score (joint-type): ", joint_structural_auc_score)
            structure_type_auc_score = eval_roc_auc(ysj.numpy(), comp_loss.numpy()) * 100
            print("Dataset Name: ", args.dataset, ", AUC Score (structure type): ", structure_type_auc_score)

            best_auc_dense_structural = max(best_auc_dense_structural, dense_structural_auc_score)
            best_auc_joint_structural = max(best_auc_joint_structural, joint_structural_auc_score)
            best_auc_structure_type = max(best_auc_structure_type, structure_type_auc_score)

        if auc_score > best_auc:
            best_auc = auc_score
            torch.save(GNNModel.state_dict(), ckpt_path)
            print(f"[GADNR] Saved best model to {ckpt_path}")

        print("===========================================================================================")
        print("Dataset Name: ", args.dataset, " Best AUC Score(benchmark/combined): ", best_auc)
        if calculate_contextual:
            print("Dataset Name: ", args.dataset, " Best AUC Score (contextual): ", best_auc_contextual)
        if calculate_structural:
            print("Dataset Name: ", args.dataset, " Best AUC Score (structural): ", best_auc_dense_structural)
            print("Dataset Name: ", args.dataset, " Best AUC Score (joint-type): ", best_auc_joint_structural)
            print("Dataset Name: ", args.dataset, " Best AUC Score (structure type): ", best_auc_structure_type)
        print("===========================================================================================")

        if loss < min_loss:
            min_loss = loss
            arg_min_loss_per_node = loss_per_node

        opt.zero_grad()
        loss.backward()
        opt.step()

        loss_values.append(loss.cpu().detach())
        if args.plot_loss:
            plt.plot(np.array([lv.item() for lv in loss_values]), 'r')
            plt.title("Training Loss")
            plt.show()

    return min_loss.item(), arg_min_loss_per_node.cpu().detach()


def evaluate(model, embeddings, labels, mask):
    model.eval()
    with torch.no_grad():
        logits = model(embeddings)
        logits = logits[mask]
        labels = labels[mask]
        _, indices = torch.max(logits, dim=1)
        correct = torch.sum(indices == labels)
        return correct.item() * 1.0 / len(labels)


def train_real_datasets(dataset_str, epoch_num=10, lr=5e-6, encoder="GCN",
                        lambda_loss1=1e-2, lambda_loss2=1e-3, lambda_loss3=1e-3, sample_size=8, loss_step=20, hidden_dim=None,
                        real_loss=False, calculate_contextual=False, calculate_structural=False,
                        device=None, args=None):
    """
    ★ 关键修改：这里不再手写加载流程，统一走 dataset.load_and_prepare_dataset ★
    """
    # —— 一步得到：data（已加自环，已 to(device)）、y、yc、ys、yj、ysj —— #
    data, y, yc, ys, yj, ysj = load_and_prepare_dataset(
        dataset_str=dataset_str,
        device=device,
        args=args
    )

    # —— 直接进入训练 —— #
    loss, loss_per_node = train(
        data, y, yc, ys, yj, ysj,
        lr=lr, epoch=epoch_num, device=device, encoder=encoder,
        lambda_loss1=lambda_loss1, lambda_loss2=lambda_loss2, lambda_loss3=lambda_loss3,
        hidden_dim=hidden_dim, sample_size=sample_size, loss_step=loss_step,
        real_loss=real_loss,
        calculate_contextual=calculate_contextual,
        calculate_structural=calculate_structural,
        args=args
    )
    return loss, loss_per_node


def str2bool(v):
    if isinstance(v, bool): return v
    v = str(v).lower()
    if v in ("yes","true","t","1","y"): return True
    if v in ("no","false","f","0","n"): return False
    raise argparse.ArgumentTypeError("Boolean value expected.")

if __name__ == "__main__":
    # 提前刷新：确保日志即时显示
    try:
        import sys as _sys
        _sys.stdout.reconfigure(line_buffering=True)
        _sys.stderr.reconfigure(line_buffering=True)
    except Exception:
        pass

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, default="reddit",
                        choices=["yelp","amazon","tfinance","reddit"])
    parser.add_argument("--epoch_num", type=int, default=200)
    parser.add_argument("--encoder", type=str, default="GCN",
                        choices=["GCN","GIN","GAT","SAGE"])
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--dimension", type=int, default=16)
    parser.add_argument("--sample_size", type=int, default=10)
    parser.add_argument("--loss_step", type=int, default=50)

    # 三个重建损失的权重（保持论文设定）
    parser.add_argument("--lambda_loss1", type=float, default=1e-2)  # neighbor
    parser.add_argument("--lambda_loss2", type=float, default=0.5)   # feature
    parser.add_argument("--lambda_loss3", type=float, default=0.8)   # degree

    # 显示用的“组合分数”权重（不改动训练图）
    parser.add_argument("--h_loss_weight", type=float, default=1e-2)
    parser.add_argument("--feature_loss_weight", type=float, default=0.2)
    parser.add_argument("--degree_loss_weight", type=float, default=0.8)

    # 异常注入与特征归一化
    parser.add_argument("--normalize_feat", type=str2bool, default=False)
    parser.add_argument("--calculate_contextual", type=str2bool, default=True)
    parser.add_argument("--contextual_n", type=int, default=183)
    parser.add_argument("--contextual_k", type=int, default=30)
    parser.add_argument("--calculate_structural", type=str2bool, default=True)
    parser.add_argument("--structural_n", type=int, default=183)
    parser.add_argument("--structural_m", type=int, default=30)
    parser.add_argument("--use_combine_outlier", type=str2bool, default=False)

    # 数据文件位置（四个数据集本地放 /autodl-tmp）
    parser.add_argument("--data_root", type=str, default="/autodl-tmp")
    parser.add_argument("--prefer_local_pt", type=str2bool, default=True)
    parser.add_argument("--pt_path", type=str, default="")  # 如需指定 reddit.pt 的绝对路径

    # 其它
    parser.add_argument("--real_loss", type=str2bool, default=False)
    parser.add_argument("--neigh_loss", type=str, default="KL", choices=["KL","W2"])
    parser.add_argument("--plot_loss", type=str2bool, default=False)

    # 兼容某些环境会偷偷传 -f
    parser.add_argument("-f", default="", help=argparse.SUPPRESS)
    #new
    parser.add_argument("--tfinance_edge_keep", type=float, default=1.0)
    
    args = parser.parse_args()

    # 设备
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(">>> GAD-NR: Graph Anomaly Detection via Neighborhood Reconstruction")
    print(dict(
        dataset=args.dataset, lr=args.lr, epoch_num=args.epoch_num, encoder=args.encoder,
        dimension=args.dimension, sample_size=args.sample_size, loss_step=args.loss_step,
        lambda_loss1=args.lambda_loss1, lambda_loss2=args.lambda_loss2, lambda_loss3=args.lambda_loss3,
        normalize_feat=args.normalize_feat,
        contextual=args.calculate_contextual, structural=args.calculate_structural,
        contextual_n=args.contextual_n, contextual_k=args.contextual_k,
        structural_n=args.structural_n, structural_m=args.structural_m,
        use_combine_outlier=args.use_combine_outlier,
        data_root=args.data_root, pt_path=args.pt_path or "(auto)"
    ), flush=True)

    # 真正开始
    _ = train_real_datasets(
        dataset_str=args.dataset,
        epoch_num=args.epoch_num,
        lr=args.lr,
        encoder=args.encoder,
        lambda_loss1=args.lambda_loss1,
        lambda_loss2=args.lambda_loss2,
        lambda_loss3=args.lambda_loss3,
        sample_size=args.sample_size,
        loss_step=args.loss_step,
        hidden_dim=args.dimension,
        real_loss=args.real_loss,
        calculate_contextual=args.calculate_contextual,
        calculate_structural=args.calculate_structural,
        device=device,
        args=args,
    )