# utils.py
# ------------------------------------------------------------
# 本文件汇总“非损失类”的通用工具与模块，便于在项目各处复用：
# - 参数/评估工具：str2bool, compute_best_f1, compute_best_fbeta
# - 特征工具：_normalize, rank_normalize, zscore
# - 图工具：build_adj_from_dict, build_neighbor_dict_and_degree
# - 通用网络模块：PairNorm, MLP, FNN, MLP_generator
# - 异常注入：gen_joint_structural_outliers（兼容老/新两种调用方式）
#   * 注意：KL/W2/NCE 等损失请在 losses.py 中引用
# ------------------------------------------------------------

from typing import Dict, List, Tuple, Optional
import math
import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------------------
# 参数与评估工具
# ------------------------------
def str2bool(v):
    """将字符串/布尔值安全转为 bool（用于 argparse）"""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    v = str(v).lower()
    if v in ("yes", "true", "t", "1", "y"):
        return True
    if v in ("no", "false", "f", "0", "n"):
        return False
    import argparse as _argparse
    raise _argparse.ArgumentTypeError("Boolean value expected.")

def compute_best_f1(y_true: np.ndarray, scores: np.ndarray) -> Tuple[float, float, float, float]:
    """基于 PR 曲线在全阈值上搜索最佳 F1，返回 (best_f1, best_thr, precision, recall)"""
    from sklearn.metrics import precision_recall_curve
    p, r, thr = precision_recall_curve(y_true, scores)
    f1s = (2 * p * r) / (p + r + 1e-12)
    if np.all(np.isnan(f1s)):
        return 0.0, 1.0, 0.0, 0.0
    i = int(np.nanargmax(f1s))
    best_thr = 0.0 if i == 0 else float(thr[i - 1])
    return float(f1s[i]), best_thr, float(p[i]), float(r[i])

def compute_best_fbeta(y_true: np.ndarray, scores: np.ndarray, beta: float = 0.5) -> Tuple[float, float, float, float]:
    """基于 PR 曲线在全阈值上搜索最佳 F_beta，返回 (best_fbeta, best_thr, precision, recall)"""
    from sklearn.metrics import precision_recall_curve
    p, r, thr = precision_recall_curve(y_true, scores)
    b2 = beta * beta
    fbs = ((1 + b2) * p * r) / (b2 * p + r + 1e-12)
    if np.all(np.isnan(fbs)):
        return 0.0, 1.0, 0.0, 0.0
    i = int(np.nanargmax(fbs))
    best_thr = 0.0 if i == 0 else float(thr[i - 1])
    return float(fbs[i]), best_thr, float(p[i]), float(r[i])

# ------------------------------
# 向量与特征工具
# ------------------------------
def _normalize(x: torch.Tensor) -> torch.Tensor:
    """按 min-max 归一化到 [0,1]（与原始实现一致）"""
    x_min = x.min()
    x_max = x.max()
    return (x - x_min) / (x_max - x_min + 1e-8)

def rank_normalize(v: np.ndarray) -> np.ndarray:
    """将一维分数转为 [0,1] 的秩归一化（越大越异常）"""
    ranks = v.argsort().argsort().astype(float)
    return ranks / (len(ranks) - 1 + 1e-8)

def zscore(v: np.ndarray) -> np.ndarray:
    """标准化（均值方差）"""
    m, s = v.mean(), v.std() + 1e-12
    return (v - m) / s

# ------------------------------
# 图结构工具
# ------------------------------
def build_adj_from_dict(neighbor_dict: Dict[int, List[int]], n: int) -> List[List[int]]:
    """
    将 {node: [neighbors]} 转为简单邻接列表（不去重）
    仅作为轻量辅助；真正训练建议直接使用 edge_index 邻接。
    """
    adj = [[] for _ in range(n)]
    for i, nbrs in neighbor_dict.items():
        for j in nbrs:
            if j != i:
                adj[i].append(j)
    return adj

def build_neighbor_dict_and_degree(edge_index: torch.Tensor, device: torch.device) -> Tuple[Dict[int, List[int]], torch.Tensor]:
    """
    从 PyG 的 edge_index 构造“无向”邻居字典与度向量（某些聚合器如 PNAConv 需要度统计）。
    注意：这里默认把边视作无向（即加入 s->t 与 t->s），更稳健。
    """
    src = edge_index[0].tolist()
    dst = edge_index[1].tolist()
    neighbor_dict: Dict[int, List[int]] = {}
    for s, t in zip(src, dst):
        neighbor_dict.setdefault(s, []).append(t)
        neighbor_dict.setdefault(t, []).append(s)
    # 以“出现过的节点索引”为基准构造度；如需严格 [0..N-1] 的全量度，可在外部按 data.num_nodes 构造
    deg_list = [len(neighbor_dict[i]) for i in neighbor_dict]
    neighbor_num_list = torch.tensor(deg_list, device=device)
    return neighbor_dict, neighbor_num_list

# ------------------------------
# 通用网络模块（与原脚本保持一致）
# ------------------------------
class PairNorm(nn.Module):
    """
    PairNorm（ICLR'19）: 解决 GNN 在深层时过平滑/过缩放问题的归一化层
    mode ∈ {'None','PN','PN-SI','PN-SCS'}
    """
    def __init__(self, mode: str = 'PN', scale: float = 10):
        super().__init__()
        assert mode in ['None', 'PN', 'PN-SI', 'PN-SCS']
        self.mode = mode
        self.scale = scale

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.mode == 'None':
            return x
        col_mean = x.mean(dim=0)
        if self.mode == 'PN':
            x = x - col_mean
            rownorm_mean = (1e-6 + x.pow(2).sum(dim=1).mean()).sqrt()
            x = self.scale * x / rownorm_mean
        if self.mode == 'PN-SI':
            x = x - col_mean
            rownorm_individual = (1e-6 + x.pow(2).sum(dim=1, keepdim=True)).sqrt()
            x = self.scale * x / rownorm_individual
        if self.mode == 'PN-SCS':
            rownorm_individual = (1e-6 + x.pow(2).sum(dim=1, keepdim=True)).sqrt()
            x = self.scale * x / rownorm_individual - col_mean
        return x

class MLP(nn.Module):
    """与原版一致的多层感知机封装（支持 num_layers=1 的纯线性）"""
    def __init__(self, num_layers: int, input_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.linear_or_not = True
        self.num_layers = num_layers
        if num_layers < 1:
            raise ValueError("number of layers should be positive!")
        elif num_layers == 1:
            self.linear = nn.Linear(input_dim, output_dim)
        else:
            self.linear_or_not = False
            self.linears = nn.ModuleList()
            self.batch_norms = nn.ModuleList()
            self.linears.append(nn.Linear(input_dim, hidden_dim))
            for _ in range(num_layers - 2):
                self.linears.append(nn.Linear(hidden_dim, hidden_dim))
            self.linears.append(nn.Linear(hidden_dim, output_dim))
            for _ in range(num_layers - 1):
                self.batch_norms.append(nn.BatchNorm1d(hidden_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.linear_or_not:
            return self.linear(x)
        h = x
        for layer in range(self.num_layers - 1):
            h = self.linears[layer](h)
            # 兼容 [B, T, C] 情况下做 BN
            if h.dim() > 2:
                h = h.transpose(0, 1).transpose(1, 2)
            h = self.batch_norms[layer](h)
            if h.dim() > 2:
                h = h.transpose(1, 2).transpose(0, 1)
            h = F.relu(h)
        return self.linears[self.num_layers - 1](h)

class FNN(nn.Module):
    """两层前馈网络：MLP(...)->ReLU->Linear->ReLU"""
    def __init__(self, in_features: int, hidden: int, out_features: int, layer_num: int):
        super().__init__()
        self.linear1 = MLP(layer_num, in_features, hidden, out_features)
        self.linear2 = nn.Linear(out_features, out_features)

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        x = self.linear1(embedding)
        x = self.linear2(F.relu(x))
        return F.relu(x)

class MLP_generator(nn.Module):
    """生成器 MLP：四层线性+ReLU（与原脚本一致）"""
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim)
        self.linear2 = nn.Linear(output_dim, output_dim)
        self.linear3 = nn.Linear(output_dim, output_dim)
        self.linear4 = nn.Linear(output_dim, output_dim)

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.linear(embedding))
        x = F.relu(self.linear2(x))
        x = F.relu(self.linear3(x))
        x = self.linear4(x)
        return x

# （可选）用于你上一个版本中的“多特征监督头”，若不需要可删除或保留备用
class ScoringHead(nn.Module):
    """
    MLP 监督头：默认 6 维输入（如 rank+h/d/f 与 zscore+h/d/f）
    用于将多源特征融合为一个异常分数的 logit
    """
    def __init__(self, in_dim: int = 6, hidden: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)

# ------------------------------
# 异常注入工具（联合结构异常）
# ------------------------------
def gen_joint_structural_outliers(
    data,
    *args,
    random_state: Optional[int] = None,
    **kwargs
):
    """
    生成“联合结构异常”（给 n 个异常节点各添 m 条随机边）。
    为了兼容你的不同版本，这里支持两种调用方式：
      1) 新式：gen_joint_structural_outliers(data, n=..., m=..., random_state=...)
      2) 旧式：gen_joint_structural_outliers(data, m, n, random_state=...)  # 注意旧式位置是 (m, n)

    返回：
      data (edge_index 已扩充), y_outlier (LongTensor, [N], 0/1)
    """
    from torch_geometric.data import Data
    from pygod.utils.utility import check_parameter
    import numpy as _np

    # 解析参数（兼容新旧）
    n = kwargs.get('n', None)
    m = kwargs.get('m', None)
    if n is None or m is None:
        # 尝试旧式位置传参：*args = (m, n) 或 (m, n, ...)
        if len(args) >= 2 and all(isinstance(v, int) for v in args[:2]):
            m, n = int(args[0]), int(args[1])
        else:
            raise ValueError("Please provide n and m (either as keywords or legacy positional (m, n)).")

    if not isinstance(data, Data):
        raise TypeError("data should be torch_geometric.data.Data")

    check_parameter(m, low=0, high=data.num_nodes, param_name='m')
    check_parameter(n, low=0, high=data.num_nodes, param_name='n')
    check_parameter(m * n, low=0, high=data.num_nodes, param_name='m*n')

    if random_state is not None:
        _np.random.seed(random_state)

    N = data.num_nodes
    outlier_idx = _np.random.choice(N, size=n, replace=False)

    # 追加边
    new_edges = []
    for i in outlier_idx.tolist():
        other_idx = _np.random.choice(N, size=m, replace=False)
        for j in other_idx:
            new_edges.append(torch.tensor([[i, j]], dtype=torch.long))

    if len(new_edges) > 0:
        new_edges = torch.cat(new_edges)
        data.edge_index = torch.cat([data.edge_index, new_edges.T], dim=1)

    y_outlier = torch.zeros(data.x.shape[0], dtype=torch.long)
    y_outlier[outlier_idx] = 1
    return data, y_outlier


__all__ = [
    # 参数/评估
    "str2bool", "compute_best_f1", "compute_best_fbeta",
    # 特征工具
    "_normalize", "rank_normalize", "zscore",
    # 图工具
    "build_adj_from_dict", "build_neighbor_dict_and_degree",
    # 网络模块
    "PairNorm", "MLP", "FNN", "MLP_generator", "ScoringHead",
    # 异常生成
    "gen_joint_structural_outliers",
]