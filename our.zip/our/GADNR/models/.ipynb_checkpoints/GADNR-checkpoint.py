import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from torch_geometric.nn import GCNConv, GINConv, SAGEConv, GATConv, GraphSAGE

# 兼容两种运行方式：
# 1）在 /root/our 下：from GADNR.models.GADNR import GNNStructEncoder
# 2）在 /root/our/GADNR 下：python train.py
try:
    # 作为包导入时（fusion_joint_tsne / fusion_train）
    from ..utils import FNN, PairNorm, MLP, MLP_generator
    from ..losses import KL_neighbor_loss, W2_neighbor_loss
except ImportError:
    # 在 GADNR 目录下直接跑 train.py
    from utils import FNN, PairNorm, MLP, MLP_generator
    from losses import KL_neighbor_loss, W2_neighbor_loss

class GNNStructEncoder(nn.Module):
    def __init__(self, in_dim0, in_dim, hidden_dim, layer_num, sample_size, device, neighbor_num_list,
                 GNN_name="GIN", norm_mode="PN-SCS", norm_scale=20,
                 lambda_loss1=0.01, lambda_loss2=0.001, lambda_loss3=0.0001):

        super(GNNStructEncoder, self).__init__()
        self.mlp0 = nn.Linear(in_dim0, hidden_dim)
        self.norm = PairNorm(norm_mode, norm_scale)
        self.out_dim = hidden_dim
        self.lambda_loss1 = lambda_loss1
        self.lambda_loss2 = lambda_loss2
        self.lambda_loss3 = lambda_loss3

        if GNN_name == "GIN":
            self.linear1 = MLP(layer_num, hidden_dim, hidden_dim, hidden_dim)
            self.graphconv1 = GINConv(self.linear1)
            self.linear2 = MLP(layer_num, hidden_dim, hidden_dim, hidden_dim)
            self.graphconv2 = GINConv(self.linear2)
        elif GNN_name == "GCN":
            self.graphconv1 = GCNConv(hidden_dim, hidden_dim)
            self.graphconv2 = GCNConv(hidden_dim, hidden_dim)
        elif GNN_name == "GAT":
            self.graphconv1 = GATConv(hidden_dim, hidden_dim)
            self.graphconv2 = GATConv(hidden_dim, hidden_dim)
        else:
            self.graphconv1 = SAGEConv(hidden_dim, hidden_dim, aggr='mean')

        self.neighbor_num_list = neighbor_num_list
        self.tot_node = len(neighbor_num_list)

        self.gaussian_mean = nn.Parameter(
            torch.FloatTensor(sample_size, hidden_dim).uniform_(-0.5 / hidden_dim, 0.5 / hidden_dim)
        )
        self.gaussian_log_sigma = nn.Parameter(
            torch.FloatTensor(sample_size, hidden_dim).uniform_(-0.5 / hidden_dim, 0.5 / hidden_dim)
        )

        self.m = torch.distributions.Normal(torch.zeros(sample_size, hidden_dim), torch.ones(sample_size, hidden_dim))
        self.m_batched = torch.distributions.Normal(
            torch.zeros(sample_size, self.tot_node, hidden_dim),
            torch.ones(sample_size, self.tot_node, hidden_dim)
        )
        self.m_h = torch.distributions.Normal(torch.zeros(sample_size, hidden_dim), 50 * torch.ones(sample_size, hidden_dim))

        self.mlp_gaussian_mean = nn.Parameter(
            torch.FloatTensor(hidden_dim).uniform_(-0.5 / hidden_dim, 0.5 / hidden_dim)
        )
        self.mlp_gaussian_log_sigma = nn.Parameter(
            torch.FloatTensor(hidden_dim).uniform_(-0.5 / hidden_dim, 0.5 / hidden_dim)
        )
        self.mlp_m = torch.distributions.Normal(torch.zeros(hidden_dim), torch.ones(hidden_dim))
        self.mlp_mean = FNN(hidden_dim, hidden_dim, hidden_dim, 3)
        self.mlp_sigma = FNN(hidden_dim, hidden_dim, hidden_dim, 3)
        self.softplus = nn.Softplus()

        # ✅ 替换 PNAConv，避免显存爆炸
        self.mean_agg = GraphSAGE(hidden_dim, hidden_dim, aggr='mean', num_layers=1)
        self.std_agg  = SAGEConv(hidden_dim, hidden_dim, aggr='mean')  # 用 mean 近似 std

        self.layer1_generator = MLP_generator(hidden_dim, hidden_dim)

        self.degree_decoder = FNN(hidden_dim, hidden_dim, 1, 4)
        self.feature_decoder = FNN(hidden_dim, hidden_dim, in_dim, 3)
        self.degree_loss_func = nn.MSELoss()
        self.feature_loss_func = nn.MSELoss()
        self.in_dim = in_dim
        self.sample_size = sample_size
        self.init_projection = FNN(in_dim, hidden_dim, hidden_dim, 1)

    def forward_encoder(self, x, edge_index):
        h0 = self.mlp0(x)
        l1 = self.graphconv1(h0, edge_index)
        return l1, h0

    def forward(self, edge_index, x, ground_truth_degree_matrix, neighbor_dict, device):
        l1, h0 = self.forward_encoder(x, edge_index)
        # ✅ 直接把 l1 传下去，避免重复调用 graphconv1
        loss, loss_per_node, h_loss, degree_loss, feature_loss = self.neighbor_decoder(
            l1, ground_truth_degree_matrix, h0, neighbor_dict, device, x, edge_index
        )
        return loss, loss_per_node, h_loss, degree_loss, feature_loss
    
    
        # ===== 新增：只返回结构 embedding 的接口 =====
    @torch.no_grad()
    def encode_only(self, edge_index, x, device=None):
        """
        只走编码器，返回每个节点的结构表征 l1，尺寸 [N, hidden_dim]
        不参与梯度计算，用于 Joint 表征和可视化。
        """
        if device is not None:
            edge_index = edge_index.to(device)
            x = x.to(device)
        self.eval()
        l1, _ = self.forward_encoder(x, edge_index)
        return l1

    def reconstruction_neighbors2(self, l1, h0, edge_index):
        # ✅ 避免重复调用 graphconv1，直接用 l1 当 mean_neigh
        mean_neigh = l1

        # 轻量近似“std” + 保证非负&上界
        std_neigh = torch.relu(self.std_agg(h0, edge_index))
        std_neigh = torch.clamp(std_neigh, 0.0, 10.0)

        target_cov = torch.bmm(std_neigh.unsqueeze(-1), std_neigh.unsqueeze(1))
        target_mean = mean_neigh

        # 生成样本
        self_emb = l1.unsqueeze(0).repeat(self.sample_size, 1, 1)
        gen_mean  = self.mlp_mean(self_emb)
        gen_sigma = self.mlp_sigma(self_emb)
        gen_sigma = torch.clamp(gen_sigma, -5.0, 5.0)

        std_z = self.m_batched.sample().to(l1.device)
        var   = gen_mean + gen_sigma.exp() * std_z
        nhij  = self.layer1_generator(var)

        gen_mean = nhij.mean(dim=0)
        gen_std  = nhij.std(dim=0).clamp(0.0, 10.0)
        gen_cov  = torch.bmm(gen_std.unsqueeze(-1), gen_std.unsqueeze(1)) / max(self.sample_size, 1)

        N, D = l1.shape
        with torch.cuda.amp.autocast(enabled=False):
            I = torch.eye(D, device=l1.device, dtype=torch.float32).unsqueeze(0).repeat(N,1,1)
            A = (target_cov.float()    + I)
            B = (gen_cov.float()       + I)
            mu_t = target_mean.float()
            mu_g = gen_mean.float()

            sign_A, logdet_A = torch.linalg.slogdet(A)
            sign_B, logdet_B = torch.linalg.slogdet(B)

            L = torch.linalg.cholesky(B)
            Y = torch.cholesky_solve(A, L)
            trace_term = torch.diagonal(Y, dim1=-2, dim2=-1).sum(-1)

            diff = (mu_g - mu_t).unsqueeze(-1)
            u   = torch.cholesky_solve(diff, L)
            quad = (diff.transpose(1,2) @ u).squeeze(-1).squeeze(-1)

            KL = 0.5 * ((logdet_A - logdet_B) - D + trace_term + quad)

        return KL.mean(), KL

    def neighbor_decoder(self, gij, ground_truth_degree_matrix, h0, neighbor_dict, device, h, edge_index):
        tot_nodes = gij.shape[0]
        degree_logits = F.relu(self.degree_decoder(gij))
        ground_truth_degree_matrix = ground_truth_degree_matrix.unsqueeze(1)
        degree_loss = self.degree_loss_func(degree_logits, ground_truth_degree_matrix.float())
        degree_loss_per_node = (degree_logits - ground_truth_degree_matrix).pow(2)

        h_loss = 0
        feature_loss = 0
        h_loss_per_node_accum = torch.zeros(tot_nodes, 1, device=device)
        feature_loss_per_node_accum = torch.zeros(tot_nodes, 1, device=device)

        for _ in range(3):
            h0_prime = self.feature_decoder(gij)
            feature_losses_per_node = (h0 - h0_prime).pow(2).mean(1, keepdim=True)
            feature_loss_per_node_accum += feature_losses_per_node
            feature_loss += feature_losses_per_node.mean()

            # ✅ 直接传 l1 (gij)，不再调用 graphconv1
            local_index_loss, local_index_loss_per_node = self.reconstruction_neighbors2(gij, h0, edge_index)
            h_loss += local_index_loss

            if local_index_loss_per_node.dim() == 1:
                v = local_index_loss_per_node.unsqueeze(1)
            elif local_index_loss_per_node.dim() == 2:
                v = local_index_loss_per_node.mean(dim=-1, keepdim=True)
            else:
                v = local_index_loss_per_node.view(tot_nodes, -1).mean(dim=-1, keepdim=True)

            h_loss_per_node_accum += v

        h_loss /= 3
        feature_loss /= 3
        h_loss_per_node = h_loss_per_node_accum / 3
        feature_loss_per_node = feature_loss_per_node_accum / 3
        degree_loss_per_node = degree_loss_per_node.view(tot_nodes, 1)

        loss = (
            self.lambda_loss1 * h_loss
            + self.lambda_loss3 * degree_loss
            + self.lambda_loss2 * feature_loss
        )
        loss_per_node = (
            self.lambda_loss1 * h_loss_per_node
            + self.lambda_loss3 * degree_loss_per_node
            + self.lambda_loss2 * feature_loss_per_node
        )
        return loss, loss_per_node, h_loss_per_node, degree_loss_per_node, feature_loss_per_node
